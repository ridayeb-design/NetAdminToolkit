package com.netadmin.toolkit.tools

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.netadmin.toolkit.net.PING_TIME
import com.netadmin.toolkit.net.isIPv6Literal
import com.netadmin.toolkit.net.pingBinary
import com.netadmin.toolkit.net.runProcess
import com.netadmin.toolkit.ui.Console
import com.netadmin.toolkit.ui.RunStopButton
import com.netadmin.toolkit.ui.StatRow
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

@Composable
fun HostField(value: String, onChange: (String) -> Unit, label: String = "Host or IP", modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = value, onValueChange = { onChange(it.trim()) }, label = { Text(label) }, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, autoCorrectEnabled = false),
        modifier = modifier.fillMaxWidth(),
    )
}

@Composable
fun NumField(value: String, onChange: (String) -> Unit, label: String, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = value, onValueChange = { v -> onChange(v.filter { it.isDigit() || it == '.' }) },
        label = { Text(label) }, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = modifier,
    )
}

@Composable
fun PingScreen(initialHost: String) {
    val scope = rememberCoroutineScope()
    var host by rememberSaveable { mutableStateOf("8.8.8.8") }
    LaunchedEffect(initialHost) {
        val h = initialHost.substringBefore('#')
        if (h.isNotBlank()) host = h
    }
    var count by rememberSaveable { mutableStateOf("10") }
    var interval by rememberSaveable { mutableStateOf("1") }
    var size by rememberSaveable { mutableStateOf("56") }
    var ttl by rememberSaveable { mutableStateOf("64") }
    var v6 by rememberSaveable { mutableStateOf(false) }
    var continuous by rememberSaveable { mutableStateOf(false) }
    val lines = remember { mutableStateListOf<String>() }
    val rtts = remember { mutableStateListOf<Double>() }
    var sent by remember { mutableStateOf(0) }
    var job by remember { mutableStateOf<Job?>(null) }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            HostField(host, { host = it })
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NumField(count, { count = it }, "Count", Modifier.weight(1f))
                NumField(interval, { interval = it }, "Interval s", Modifier.weight(1f))
                NumField(size, { size = it }, "Bytes", Modifier.weight(1f))
                NumField(ttl, { ttl = it }, "TTL", Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = continuous, onClick = { continuous = !continuous }, label = { Text("Continuous") })
                FilterChip(selected = v6, onClick = { v6 = !v6 }, label = { Text("IPv6") })
                RunStopButton(
                    running = job?.isActive == true,
                    modifier = Modifier.weight(1f),
                    onRun = {
                        lines.clear(); rtts.clear(); sent = 0
                        val ipv6 = v6 || isIPv6Literal(host)
                        val iv = (interval.toDoubleOrNull() ?: 1.0).coerceAtLeast(0.2) // non-root minimum
                        val cmd = buildList {
                            add(pingBinary(ipv6)); add("-n")
                            if (!continuous) { add("-c"); add((count.toIntOrNull() ?: 4).toString()) }
                            add("-i"); add(iv.toString())
                            add("-s"); add((size.toIntOrNull() ?: 56).toString())
                            if (!ipv6) { add("-t"); add((ttl.toIntOrNull() ?: 64).toString()) }
                            add("-W"); add("2")
                            add(host)
                        }
                        lines += "$ " + cmd.joinToString(" ")
                        job = scope.launch {
                            try {
                                runProcess(cmd) { l ->
                                    lines += l
                                    SEQ.find(l)?.groupValues?.get(1)?.toIntOrNull()?.let { if (it > sent) sent = it }
                                    TX.find(l)?.groupValues?.get(1)?.toIntOrNull()?.let { sent = it }
                                    PING_TIME.find(l)?.groupValues?.get(1)?.toDoubleOrNull()?.let { rtts += it }
                                }
                            } catch (e: Exception) {
                                if (e !is kotlinx.coroutines.CancellationException) lines += "Error: ${e.message}"
                            }
                        }
                    },
                    onStop = { job?.cancel(); lines += "— stopped —" },
                )
            }
        }
        if (rtts.isNotEmpty() || sent > 0) {
            val loss = if (sent > 0) (100 - rtts.size * 100 / sent).coerceAtLeast(0) else 0
            StatRow(
                listOf(
                    "replies" to "${rtts.size}/$sent",
                    "loss" to "$loss%",
                    "min" to (rtts.minOrNull()?.let { "%.1f".format(it) } ?: "—"),
                    "avg" to (rtts.takeIf { it.isNotEmpty() }?.average()?.let { "%.1f".format(it) } ?: "—"),
                    "max" to (rtts.maxOrNull()?.let { "%.1f".format(it) } ?: "—"),
                    "jitter" to jitter(rtts),
                ),
            )
        }
        Console(lines, Modifier.weight(1f))
    }
}

private val SEQ = Regex("""icmp_seq=(\d+)""")
private val TX = Regex("""(\d+) packets transmitted""")

private fun jitter(r: List<Double>): String {
    if (r.size < 2) return "—"
    val j = r.zipWithNext { a, b -> kotlin.math.abs(b - a) }.average()
    return "%.1f".format(j)
}
