package com.netadmin.toolkit.tools

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.netadmin.toolkit.net.ProbeDispatcher
import com.netadmin.toolkit.net.clean
import com.netadmin.toolkit.ui.RunStopButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket

private val SERVICES = mapOf(
    20 to "ftp-data", 21 to "ftp", 22 to "ssh", 23 to "telnet", 25 to "smtp", 53 to "dns", 67 to "dhcp",
    69 to "tftp", 80 to "http", 88 to "kerberos", 110 to "pop3", 111 to "rpcbind", 123 to "ntp", 135 to "msrpc",
    139 to "netbios", 143 to "imap", 161 to "snmp", 179 to "bgp", 389 to "ldap", 443 to "https", 445 to "smb",
    465 to "smtps", 514 to "syslog", 515 to "lpd", 548 to "afp", 554 to "rtsp", 587 to "submission",
    631 to "ipp", 636 to "ldaps", 853 to "dns-tls", 873 to "rsync", 902 to "vmware", 993 to "imaps",
    995 to "pop3s", 1080 to "socks", 1194 to "openvpn", 1433 to "mssql", 1521 to "oracle", 1723 to "pptp",
    1883 to "mqtt", 2049 to "nfs", 2082 to "cpanel", 2222 to "ssh-alt", 3000 to "dev-http", 3128 to "squid",
    3306 to "mysql", 3389 to "rdp", 4443 to "https-alt", 5000 to "upnp/synology", 5060 to "sip",
    5222 to "xmpp", 5353 to "mdns", 5432 to "postgres", 5900 to "vnc", 5985 to "winrm", 5986 to "winrm-s",
    6379 to "redis", 6443 to "k8s-api", 7547 to "tr-069", 8000 to "http-alt", 8008 to "http-alt",
    8080 to "http-proxy", 8081 to "http-alt", 8443 to "https-alt", 8888 to "http-alt", 9000 to "portainer",
    9090 to "prometheus", 9100 to "jetdirect", 9200 to "elastic", 10000 to "webmin", 11211 to "memcached",
    27017 to "mongodb", 32400 to "plex", 51820 to "wireguard", 62078 to "iphone-sync",
)

fun serviceName(p: Int) = SERVICES[p] ?: "?"

private val PRESETS = linkedMapOf(
    "Common" to SERVICES.keys.sorted().joinToString(","),
    "Web" to "80,443,8000,8008,8080,8081,8443,8888,3000,5000,9000,9090",
    "Infra" to "22,23,53,161,179,389,443,514,830,3389,5985,8291,8728",
    "1-1024" to "1-1024",
    "All" to "1-65535",
)

fun parsePorts(spec: String): List<Int> = spec.split(',', ' ', ';').filter { it.isNotBlank() }.flatMap { part ->
    if ('-' in part) {
        val (a, b) = part.split('-', limit = 2).map { it.trim().toIntOrNull() ?: 0 }
        (a.coerceIn(1, 65535)..b.coerceIn(1, 65535)).toList()
    } else listOfNotNull(part.trim().toIntOrNull()?.takeIf { it in 1..65535 })
}.distinct()

data class OpenPort(val port: Int, val ms: Long, val banner: String?)

private fun grabBanner(s: Socket, host: String, port: Int): String? = runCatching {
    s.soTimeout = 800
    val httpish = port in listOf(80, 8000, 8008, 8080, 8081, 8888, 3000, 5000, 9000, 9090)
    if (httpish) s.getOutputStream().apply { write("HEAD / HTTP/1.0\r\nHost: $host\r\n\r\n".toByteArray()); flush() }
    val buf = ByteArray(512)
    val n = s.getInputStream().read(buf)
    if (n <= 0) null else {
        val txt = String(buf, 0, n, Charsets.ISO_8859_1)
        if (httpish) txt.lines().filter { it.startsWith("HTTP/") || it.startsWith("Server:", true) }.joinToString(" | ")
        else txt.lines().firstOrNull()?.filter { it.code in 32..126 }
    }?.take(120)?.ifBlank { null }
}.getOrNull()

@Composable
fun PortScanScreen(initialHost: String) {
    val scope = rememberCoroutineScope()
    var host by rememberSaveable { mutableStateOf("scanme.nmap.org") }
    LaunchedEffect(initialHost) {
        val h = initialHost.substringBefore('#')
        if (h.isNotBlank()) host = h
    }
    var ports by rememberSaveable { mutableStateOf(PRESETS["Common"]!!) }
    var timeout by rememberSaveable { mutableStateOf("700") }
    var banners by rememberSaveable { mutableStateOf(true) }
    val open = remember { mutableStateListOf<OpenPort>() }
    var done by remember { mutableIntStateOf(0) }
    var total by remember { mutableIntStateOf(0) }
    var status by remember { mutableStateOf<String?>(null) }
    var job by remember { mutableStateOf<Job?>(null) }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            HostField(host, { host = it })
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                PRESETS.forEach { (k, v) -> FilterChip(selected = ports == v, onClick = { ports = v }, label = { Text(k) }) }
                FilterChip(selected = banners, onClick = { banners = !banners }, label = { Text("Banners") })
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(ports, { ports = it }, label = { Text("Ports (e.g. 22,80,1000-2000)") },
                    singleLine = true, modifier = Modifier.weight(1f))
                NumField(timeout, { timeout = it }, "Timeout ms", Modifier.width(110.dp))
            }
            RunStopButton(
                running = job?.isActive == true, modifier = Modifier.fillMaxWidth(), runLabel = "Scan",
                onRun = {
                    open.clear(); done = 0
                    val list = parsePorts(ports)
                    total = list.size
                    val to = (timeout.toIntOrNull() ?: 700).coerceIn(100, 10000)
                    status = "Resolving…"
                    val t0 = System.currentTimeMillis()
                    job = scope.launch {
                        try {
                            val addr = withContext(Dispatchers.IO) { InetAddress.getByName(host) }
                            status = "Scanning ${addr.clean()} — ${list.size} ports"
                            val sem = Semaphore(100)
                            list.map { p ->
                                async(ProbeDispatcher) {
                                    sem.withPermit {
                                        val r = runCatching {
                                            Socket().use { s ->
                                                val a = System.currentTimeMillis()
                                                s.connect(InetSocketAddress(addr, p), to)
                                                val ms = System.currentTimeMillis() - a
                                                OpenPort(p, ms, if (banners) grabBanner(s, host, p) else null)
                                            }
                                        }.getOrNull()
                                        withContext(Dispatchers.Main) {
                                            done++
                                            if (r != null) {
                                                val at = open.indexOfFirst { it.port > r.port }
                                                if (at < 0) open.add(r) else open.add(at, r)
                                            }
                                        }
                                    }
                                }
                            }.awaitAll()
                            status = "${open.size} open of ${list.size} · ${(System.currentTimeMillis() - t0) / 1000.0}s"
                        } catch (e: Exception) {
                            status = if (e is kotlinx.coroutines.CancellationException) "Stopped" else "Error: ${e.message}"
                        }
                    }
                },
                onStop = { job?.cancel() },
            )
            if (job?.isActive == true && total > 0)
                LinearProgressIndicator(progress = { done / total.toFloat() }, modifier = Modifier.fillMaxWidth())
            status?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
            Text("Only scan hosts you administer or are authorised to test.",
                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        SelectionContainer {
            LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
                items(open, key = { it.port }) { o ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        Row {
                            Text("${o.port}/tcp", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, modifier = Modifier.width(96.dp))
                            Text(serviceName(o.port), modifier = Modifier.weight(1f))
                            Text("${o.ms} ms", fontFamily = FontFamily.Monospace)
                        }
                        o.banner?.let { Text(it, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}
