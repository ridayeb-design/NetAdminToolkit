package com.netadmin.toolkit.screens

import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.Network
import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lan
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Route
import androidx.compose.material.icons.filled.SettingsEthernet
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.netadmin.toolkit.net.NetInfo
import com.netadmin.toolkit.net.connectivity
import com.netadmin.toolkit.ui.InfoCard
import com.netadmin.toolkit.ui.InfoSection
import com.netadmin.toolkit.ui.SectionCard
import com.netadmin.toolkit.ui.asText
import com.netadmin.toolkit.ui.copyToClipboard
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private fun iconFor(title: String) = when {
    title.startsWith("Active") -> Icons.Default.Info
    title.startsWith("Link") -> Icons.Default.SettingsEthernet
    title.startsWith("Network layer") -> Icons.Default.Lan
    title.startsWith("Routing") -> Icons.Default.Route
    title.startsWith("DNS") -> Icons.Default.Dns
    title.startsWith("Network cap") -> Icons.Default.VerifiedUser
    title.startsWith("Internet") -> Icons.Default.Public
    title.startsWith("All") -> Icons.Default.Hub
    else -> Icons.Default.Language
}

@Composable
fun OverviewScreen() {
    val ctx = LocalContext.current
    var local by remember { mutableStateOf(NetInfo.collect(ctx)) }
    var public by remember { mutableStateOf<InfoSection?>(null) }
    var loadingPublic by remember { mutableStateOf(false) }
    var localTick by remember { mutableIntStateOf(0) }
    var publicTick by remember { mutableIntStateOf(0) }

    // Refresh automatically when the default network or its addressing changes.
    DisposableEffect(Unit) {
        val cm = ctx.connectivity()
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { localTick++; publicTick++ }
            override fun onLost(network: Network) { localTick++ }
            override fun onLinkPropertiesChanged(network: Network, lp: LinkProperties) { localTick++ }
        }
        runCatching { cm.registerDefaultNetworkCallback(cb, Handler(Looper.getMainLooper())) }
        onDispose { runCatching { cm.unregisterNetworkCallback(cb) } }
    }
    LaunchedEffect(localTick) { local = withContext(Dispatchers.IO) { NetInfo.collect(ctx) } }
    LaunchedEffect(publicTick) {
        loadingPublic = true
        public = withContext(Dispatchers.IO) { NetInfo.publicInfo() }
        loadingPublic = false
    }

    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                FilledTonalButton(onClick = { localTick++; publicTick++ }) {
                    Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(6.dp)); Text("Refresh")
                }
                OutlinedButton(onClick = {
                    ctx.copyToClipboard((listOfNotNull(public) + local).asText(), "Network report")
                }) {
                    Icon(Icons.Default.ContentCopy, null); Spacer(Modifier.width(6.dp)); Text("Copy report")
                }
            }
        }
        item {
            val p = public
            if (p == null || loadingPublic) {
                InfoCard("Internet / public", Icons.Default.Public) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.padding(4.dp).size(20.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(10.dp)); Text("Looking up public IP…")
                    }
                }
            } else SectionCard(p, Icons.Default.Public)
        }
        items(local, key = { it.title }) { s -> SectionCard(s, iconFor(s.title)) }
        item { Spacer(Modifier.padding(bottom = 24.dp)) }
    }
}
