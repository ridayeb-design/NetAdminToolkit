package com.netadmin.toolkit.tools

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.netadmin.toolkit.net.PING_TIME
import com.netadmin.toolkit.net.clean
import com.netadmin.toolkit.net.execCapture
import com.netadmin.toolkit.net.pingBinary
import com.netadmin.toolkit.net.pingOnce
import com.netadmin.toolkit.net.reverseDns
import com.netadmin.toolkit.ui.RunStopButton
import com.netadmin.toolkit.ui.copyToClipboard
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.Inet6Address
import java.net.InetAddress

data class Hop(val ttl: Int, val ip: String?, val rtt: Double?, val name: String? = null, val reached: Boolean = false)

private val FROM = Regex("""From ([0-9a-fA-F:.]*[0-9a-fA-F])""")
private val BYTES_FROM = Regex("""bytes from ([0-9a-fA-F:.]*[0-9a-fA-F])""")

/** One probe with a given TTL using the system ping (no root needed). */
private fun probeHop(target: String, ttl: Int, v6: Boolean): Hop {
    val args = buildList {
        add(pingBinary(v6)); add("-n"); add("-c"); add("1"); add("-W"); add("2")
        add("-t"); add("$ttl") // TTL (IPv4) / hop limit (IPv6)
        add(target)
    }
    val t0 = System.nanoTime()
    val out = execCapture(args, 3500)
    val wall = (System.nanoTime() - t0) / 1e6
    BYTES_FROM.find(out)?.let { m ->
        return Hop(ttl, m.groupValues[1], PING_TIME.find(out)?.groupValues?.get(1)?.toDoubleOrNull() ?: wall, reached = true)
    }
    FROM.find(out)?.let { m -> return Hop(ttl, m.groupValues[1], null) }
    return Hop(ttl, null, null)
}

@Composable
fun TracerouteScreen(initialHost: String) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var host by rememberSaveable { mutableStateOf(initialHost.ifBlank { "1.1.1.1" }) }
    var maxHops by rememberSaveable { mutableStateOf("30") }
    var resolve by rememberSaveable { mutableStateOf(true) }
    val hops = remember { mutableStateListOf<Hop>() }
    var status by remember { mutableStateOf<String?>(null) }
    var job by remember { mutableStateOf<Job?>(null) }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            HostField(host, { host = it })
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NumField(maxHops, { maxHops = it }, "Max hops", Modifier.width(110.dp))
                FilterChip(selected = resolve, onClick = { resolve = !resolve }, label = { Text("Resolve names") },
                    modifier = Modifier.padding(top = 8.dp))
            }
            RunStopButton(
                running = job?.isActive == true, modifier = Modifier.fillMaxWidth(), runLabel = "Trace",
                onRun = {
                    hops.clear(); status = "Resolving $host…"
                    job = scope.launch {
                        try {
                            val addr = withContext(Dispatchers.IO) { InetAddress.getByName(host) }
                            val target = addr.clean()
                            val v6 = addr is Inet6Address
                            status = "Tracing $host ($target)…"
                            val max = (maxHops.toIntOrNull() ?: 30).coerceIn(1, 64)
                            var reached = false
                            var ttl = 1
                            val batch = 6
                            while (ttl <= max && !reached) {
                                val range = ttl..minOf(ttl + batch - 1, max)
                                val results = range.map { t ->
                                    async(Dispatchers.IO) {
                                        var h = probeHop(target, t, v6)
                                        if (h.ip == null) h = probeHop(target, t, v6) // one retry
                                        if (h.ip != null && !h.reached) h = h.copy(rtt = pingOnce(h.ip!!))
                                        if (resolve && h.ip != null) h = h.copy(name = reverseDns(h.ip!!))
                                        h
                                    }
                                }.awaitAll()
                                for (h in results) {
                                    if (reached) break
                                    hops += h
                                    if (h.reached || h.ip == target) reached = true
                                }
                                ttl = range.last + 1
                            }
                            status = if (reached) "Reached $target in ${hops.size} hops" else "Destination not reached within $max hops"
                        } catch (e: Exception) {
                            if (e !is kotlinx.coroutines.CancellationException) status = "Error: ${e.message}"
                            else status = "Stopped"
                        }
                    }
                },
                onStop = { job?.cancel() },
            )
            if (job?.isActive == true) LinearProgressIndicator(Modifier.fillMaxWidth())
            status?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        }
        SelectionContainer {
            LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
                items(hops, key = { it.ttl }) { h ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        Text("${h.ttl}".padStart(2), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,
                            modifier = Modifier.width(32.dp))
                        Column(Modifier.weight(1f)) {
                            Text(h.ip ?: "* * *", fontFamily = FontFamily.Monospace)
                            h.name?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        }
                        Text(h.rtt?.let { "%.1f ms".format(it) } ?: "—", fontFamily = FontFamily.Monospace)
                    }
                    HorizontalDivider()
                }
                item {
                    if (hops.isNotEmpty() && job?.isActive != true) {
                        androidx.compose.material3.TextButton(onClick = {
                            ctx.copyToClipboard(hops.joinToString("\n") { "${it.ttl}\t${it.ip ?: "*"}\t${it.name ?: ""}\t${it.rtt?.let { r -> "%.1f ms".format(r) } ?: "*"}" })
                        }) { Text("Copy results") }
                    }
                }
            }
        }
    }
}
