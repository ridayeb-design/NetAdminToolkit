package com.netadmin.toolkit.net

import android.annotation.SuppressLint
import android.content.Context
import android.net.wifi.ScanResult
import android.net.wifi.WifiInfo
import android.net.wifi.WifiManager
import android.os.Build
import com.netadmin.toolkit.ui.InfoSection

object WifiUtil {

    fun manager(ctx: Context) = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

    fun channel(freq: Int): Int = when (freq) {
        2484 -> 14
        in 2412..2472 -> (freq - 2407) / 5
        in 5160..5895 -> (freq - 5000) / 5
        5935 -> 2
        in 5955..7115 -> (freq - 5950) / 5
        else -> -1
    }

    fun band(freq: Int) = when (freq) {
        in 2400..2500 -> "2.4 GHz"
        in 4900..5900 -> "5 GHz"
        in 5925..7125 -> "6 GHz"
        in 58000..71000 -> "60 GHz"
        else -> "?"
    }

    fun quality(rssi: Int) = ((rssi + 100) * 2).coerceIn(0, 100)

    fun standard(s: Int) = when (s) {
        1 -> "802.11a/b/g (legacy)"
        4 -> "802.11n (Wi-Fi 4)"
        5 -> "802.11ac (Wi-Fi 5)"
        6 -> "802.11ax (Wi-Fi 6/6E)"
        7 -> "802.11ad (WiGig)"
        8 -> "802.11be (Wi-Fi 7)"
        else -> "Unknown"
    }

    fun securityType(t: Int) = when (t) {
        0 -> "Open"
        1 -> "WEP"
        2 -> "WPA/WPA2-Personal (PSK)"
        3 -> "WPA/WPA2-Enterprise (EAP)"
        4 -> "WPA3-Personal (SAE)"
        5 -> "WPA3-Enterprise 192-bit"
        6 -> "Enhanced Open (OWE)"
        7 -> "WAPI-PSK"
        8 -> "WAPI-CERT"
        9 -> "WPA3-Enterprise"
        10 -> "OSEN"
        11 -> "Passpoint R1/R2"
        12 -> "Passpoint R3"
        13 -> "DPP (Easy Connect)"
        else -> "Unknown"
    }

    fun securityFromCaps(caps: String): String = when {
        caps.contains("SAE") && caps.contains("PSK") -> "WPA2/WPA3"
        caps.contains("SAE") -> "WPA3"
        caps.contains("OWE") -> "OWE"
        caps.contains("EAP") -> if (caps.contains("RSN")) "WPA2-Ent" else "WPA-Ent"
        caps.contains("RSN") || caps.contains("WPA2") -> "WPA2"
        caps.contains("WPA") -> "WPA"
        caps.contains("WEP") -> "WEP"
        else -> "Open"
    }

    fun width(w: Int) = when (w) {
        0 -> "20 MHz"; 1 -> "40 MHz"; 2 -> "80 MHz"; 3 -> "160 MHz"; 4 -> "80+80 MHz"; 5 -> "320 MHz"
        else -> "?"
    }

    fun intToIp(i: Int): String =
        if (i == 0) "—" else "${i and 0xff}.${i shr 8 and 0xff}.${i shr 16 and 0xff}.${i shr 24 and 0xff}"

    @Suppress("DEPRECATION")
    fun connection(ctx: Context): WifiInfo? = runCatching { manager(ctx).connectionInfo }.getOrNull()

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    fun sections(ctx: Context): List<InfoSection> {
        val wm = manager(ctx)
        if (!wm.isWifiEnabled) return listOf(InfoSection("Wi-Fi", listOf("State" to "Disabled")))
        val wi = connection(ctx) ?: return listOf(InfoSection("Wi-Fi", listOf("State" to "Unavailable")))
        if (wi.networkId == -1 && wi.rssi <= -127) return listOf(InfoSection("Wi-Fi", listOf("State" to "Not connected")))

        val ssid = wi.ssid?.trim('"')?.takeIf { it != WifiManager.UNKNOWN_SSID && it != "<unknown ssid>" }
        val conn = buildList {
            add("SSID" to (ssid ?: "Hidden (grant location + turn on Location)"))
            add("BSSID (AP MAC)" to (wi.bssid?.takeIf { it != "02:00:00:00:00:00" } ?: "—"))
            add("Hidden SSID" to if (wi.hiddenSSID) "Yes" else "No")
            if (Build.VERSION.SDK_INT >= 31) add("Security" to securityType(wi.currentSecurityType))
            if (Build.VERSION.SDK_INT >= 30) add("Standard" to standard(wi.wifiStandard))
            add("Network ID" to wi.networkId.toString())
        }
        val radio = buildList {
            add("RSSI" to "${wi.rssi} dBm (${quality(wi.rssi)}%)")
            add("Frequency" to "${wi.frequency} MHz")
            add("Band / Channel" to "${band(wi.frequency)} / ch ${channel(wi.frequency)}")
            add("Link speed" to "${wi.linkSpeed} Mbps")
            if (Build.VERSION.SDK_INT >= 29) {
                add("TX link speed" to "${wi.txLinkSpeedMbps} Mbps")
                add("RX link speed" to "${wi.rxLinkSpeedMbps} Mbps")
            }
            if (Build.VERSION.SDK_INT >= 30) {
                add("Max TX supported" to "${wi.maxSupportedTxLinkSpeedMbps} Mbps")
                add("Max RX supported" to "${wi.maxSupportedRxLinkSpeedMbps} Mbps")
            }
            add("5 GHz supported" to if (wm.is5GHzBandSupported) "Yes" else "No")
            if (Build.VERSION.SDK_INT >= 30) add("6 GHz supported" to if (wm.is6GHzBandSupported) "Yes" else "No")
        }
        val d = wm.dhcpInfo
        val link = ctx.lanLink()
        val dhcp = buildList {
            add("IP address" to intToIp(d.ipAddress))
            add("Netmask" to (link.ipv4Prefix?.let { longToIp(prefixToMask(it)) + " (/$it)" } ?: intToIp(d.netmask)))
            add("Gateway" to intToIp(d.gateway))
            add("DHCP server" to intToIp(d.serverAddress))
            add("DNS 1" to intToIp(d.dns1))
            add("DNS 2" to intToIp(d.dns2))
            add("Lease time" to if (d.leaseDuration > 0) "${d.leaseDuration / 3600}h ${d.leaseDuration % 3600 / 60}m" else "—")
        }
        return listOf(
            InfoSection("Connection", conn),
            InfoSection("Radio", radio),
            InfoSection("DHCP lease", dhcp),
        )
    }

    data class Ap(
        val ssid: String, val bssid: String, val rssi: Int, val freq: Int,
        val security: String, val width: String, val standard: String?,
    )

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    fun scanResults(ctx: Context): List<Ap> = runCatching {
        manager(ctx).scanResults.map { r: ScanResult ->
            Ap(
                ssid = r.SSID?.ifBlank { "<hidden>" } ?: "<hidden>",
                bssid = r.BSSID ?: "",
                rssi = r.level,
                freq = r.frequency,
                security = securityFromCaps(r.capabilities ?: ""),
                width = width(r.channelWidth),
                standard = if (Build.VERSION.SDK_INT >= 30) standard(r.wifiStandard) else null,
            )
        }.distinctBy { it.bssid + it.freq }.sortedByDescending { it.rssi }
    }.getOrDefault(emptyList())
}
