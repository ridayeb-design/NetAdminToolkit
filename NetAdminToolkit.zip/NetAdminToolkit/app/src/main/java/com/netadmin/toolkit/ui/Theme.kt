package com.netadmin.toolkit.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** Dark, utility-style palette: near-black background, light-blue accents, grey labels. */
object NetColors {
    val Background = Color(0xFF121212)
    val Surface = Color(0xFF1A1A1A)
    val SurfaceHigh = Color(0xFF242424)
    val Accent = Color(0xFF4FC3F7)
    val Label = Color(0xFF9E9E9E)
    val Divider = Color(0xFF2A2A2A)
    val Good = Color(0xFF66BB6A)
    val Warn = Color(0xFFFFCA28)
    val Bad = Color(0xFFEF5350)
}

private val Scheme = darkColorScheme(
    primary = NetColors.Accent,
    onPrimary = Color(0xFF00222E),
    secondary = Color(0xFF80CBC4),
    tertiary = NetColors.Warn,
    background = NetColors.Background,
    onBackground = Color(0xFFEDEDED),
    surface = NetColors.Background,
    onSurface = Color(0xFFEDEDED),
    surfaceVariant = NetColors.SurfaceHigh,
    onSurfaceVariant = NetColors.Label,
    surfaceContainerLowest = Color(0xFF0D0D0D),
    surfaceContainerLow = NetColors.Surface,
    surfaceContainer = NetColors.Surface,
    surfaceContainerHigh = NetColors.SurfaceHigh,
    surfaceContainerHighest = Color(0xFF0E0E0E),
    secondaryContainer = Color(0xFF0F3A4A),
    onSecondaryContainer = NetColors.Accent,
    outline = Color(0xFF3A3A3A),
    outlineVariant = NetColors.Divider,
    error = NetColors.Bad,
)

@Composable
fun NetTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, typography = Typography(), content = content)
}
