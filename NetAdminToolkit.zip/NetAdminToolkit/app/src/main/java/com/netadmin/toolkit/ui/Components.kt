package com.netadmin.toolkit.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class InfoSection(val title: String, val rows: List<Pair<String, String>>)

fun Context.copyToClipboard(text: String, label: String = "NetAdmin") {
    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText(label, text))
    Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
}

fun List<InfoSection>.asText(): String = joinToString("\n\n") { s ->
    "## ${s.title}\n" + s.rows.joinToString("\n") { "${it.first}: ${it.second}" }
}

@Composable
fun InfoCard(
    title: String,
    icon: ImageVector? = null,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit,
) {
    Card(
        modifier = modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (icon != null) {
                    Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                }
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.padding(top = 6.dp))
            content()
        }
    }
}

/** Label/value row. Tap to copy the value. */
@Composable
fun KV(label: String, value: String?) {
    val ctx = LocalContext.current
    val v = value?.takeIf { it.isNotBlank() } ?: "—"
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(enabled = value != null) { ctx.copyToClipboard(v, label) }
            .padding(vertical = 4.dp),
    ) {
        Text(
            label,
            modifier = Modifier.weight(0.42f),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
            v,
            modifier = Modifier.weight(0.58f),
            style = MaterialTheme.typography.bodyMedium,
            fontFamily = FontFamily.Monospace,
            textAlign = TextAlign.End,
        )
    }
}

@Composable
fun SectionCard(section: InfoSection, icon: ImageVector? = null) {
    InfoCard(section.title, icon) {
        section.rows.forEachIndexed { i, (k, v) ->
            if (i > 0) HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
            KV(k, v)
        }
    }
}

@Composable
fun RunStopButton(running: Boolean, onRun: () -> Unit, onStop: () -> Unit, modifier: Modifier = Modifier, runLabel: String = "Run") {
    if (running) {
        Button(
            onClick = onStop, modifier = modifier,
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
        ) { Icon(Icons.Default.Stop, null); Spacer(Modifier.width(6.dp)); Text("Stop") }
    } else {
        Button(onClick = onRun, modifier = modifier) {
            Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text(runLabel)
        }
    }
}

/** Terminal-style output panel that auto-scrolls to the newest line. */
@Composable
fun Console(lines: List<String>, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val state = rememberLazyListState()
    LaunchedEffect(lines.size) { if (lines.isNotEmpty()) state.animateScrollToItem(lines.size - 1) }
    Box(
        modifier
            .fillMaxSize()
            .padding(12.dp)
            .background(MaterialTheme.colorScheme.surfaceContainerHighest, RoundedCornerShape(10.dp)),
    ) {
        SelectionContainer {
            LazyColumn(state = state, modifier = Modifier.fillMaxSize().padding(10.dp)) {
                itemsIndexed(lines) { _, l ->
                    Text(l, fontFamily = FontFamily.Monospace, fontSize = 12.sp, lineHeight = 16.sp)
                }
            }
        }
        if (lines.isNotEmpty()) {
            IconButton(
                onClick = { ctx.copyToClipboard(lines.joinToString("\n"), "output") },
                modifier = Modifier.align(Alignment.TopEnd),
            ) { Icon(Icons.Default.ContentCopy, "Copy output") }
        }
    }
}

@Composable
fun Hint(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
    )
}

@Composable
fun StatRow(stats: List<Pair<String, String>>) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
        stats.forEach { (k, v) ->
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(v, style = MaterialTheme.typography.titleMedium, fontFamily = FontFamily.Monospace)
                Text(k, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
