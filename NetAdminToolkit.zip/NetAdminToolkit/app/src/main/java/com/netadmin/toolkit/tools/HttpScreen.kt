package com.netadmin.toolkit.tools

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.netadmin.toolkit.net.clean
import com.netadmin.toolkit.ui.Console
import com.netadmin.toolkit.ui.RunStopButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.security.cert.X509Certificate
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

object HttpCheck {
    private val df = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)

    fun run(input: String, emit: (String) -> Unit) {
        val urlStr = if (input.contains("://")) input else "https://$input"
        val url = URL(urlStr)
        val host = url.host
        val https = url.protocol.equals("https", true)
        val port = if (url.port > 0) url.port else url.defaultPort

        // 1. DNS
        var t = System.nanoTime()
        val addrs = InetAddress.getAllByName(host)
        emit("DNS        ${ms(t)}  → ${addrs.joinToString { it.clean() }}")

        // 2. TCP
        val sock = Socket()
        t = System.nanoTime()
        sock.connect(InetSocketAddress(addrs[0], port), 8000)
        emit("TCP        ${ms(t)}  → ${addrs[0].clean()}:$port")

        // 3. TLS
        if (https) {
            try {
                t = System.nanoTime()
                val ssl = (SSLSocketFactory.getDefault() as SSLSocketFactory)
                    .createSocket(sock, host, port, true) as SSLSocket
                ssl.soTimeout = 8000
                ssl.startHandshake()
                emit("TLS        ${ms(t)}  → ${ssl.session.protocol}, ${ssl.session.cipherSuite}")
                val hv = HttpsURLConnection.getDefaultHostnameVerifier().verify(host, ssl.session)
                emit("Hostname   ${if (hv) "matches certificate ✔" else "DOES NOT match certificate ✘"}")
                emit("")
                emit("Certificate chain:")
                ssl.session.peerCertificates.filterIsInstance<X509Certificate>().forEachIndexed { i, c ->
                    val days = TimeUnit.MILLISECONDS.toDays(c.notAfter.time - Date().time)
                    emit(" [$i] ${c.subjectX500Principal.name}")
                    emit("     issuer : ${c.issuerX500Principal.name}")
                    emit("     valid  : ${df.format(c.notBefore)} → ${df.format(c.notAfter)}  ($days days left${if (days < 30) " ⚠" else ""})")
                    emit("     sigalg : ${c.sigAlgName}, key ${c.publicKey.algorithm}")
                    if (i == 0) runCatching {
                        c.subjectAlternativeNames?.mapNotNull { it.getOrNull(1)?.toString() }?.let { sans ->
                            emit("     SANs   : ${sans.take(20).joinToString(", ")}${if (sans.size > 20) " (+${sans.size - 20})" else ""}")
                        }
                    }
                }
                ssl.close()
            } catch (e: Exception) {
                emit("TLS        FAILED: ${e.javaClass.simpleName}: ${e.message}")
                runCatching { sock.close() }
            }
        } else sock.close()
        emit("")

        // 4. HTTP request (fresh connection, no redirect following)
        val c = url.openConnection() as HttpURLConnection
        c.instanceFollowRedirects = false
        c.connectTimeout = 8000; c.readTimeout = 8000
        c.setRequestProperty("User-Agent", "NetAdminToolkit/1.0")
        t = System.nanoTime()
        val code = runCatching { c.responseCode }.getOrElse {
            // Certificate errors etc.
            emit("HTTP       FAILED: ${it.javaClass.simpleName}: ${it.message}"); return
        }
        emit("HTTP       ${ms(t)}  → $code ${c.responseMessage ?: ""}")
        c.getHeaderField("Location")?.let { emit("Redirect   → $it") }
        emit("")
        emit("Response headers:")
        c.headerFields.forEach { (k, v) -> if (k != null) emit("  $k: ${v.joinToString("; ")}") }
        c.disconnect()
    }

    private fun ms(t0: Long) = "%6.1f ms".format((System.nanoTime() - t0) / 1e6)
}

@Composable
fun HttpScreen(initialHost: String) {
    val scope = rememberCoroutineScope()
    var target by rememberSaveable { mutableStateOf(initialHost.let { if (it.isBlank()) "https://example.com" else if (it.contains("://")) it else "http://$it" }) }
    val lines = remember { mutableStateListOf<String>() }
    var job by remember { mutableStateOf<Job?>(null) }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            HostField(target, { target = it }, "URL (https://host[:port]/path)")
            RunStopButton(
                running = job?.isActive == true, modifier = Modifier.fillMaxWidth(), runLabel = "Check",
                onRun = {
                    lines.clear()
                    job = scope.launch {
                        withContext(Dispatchers.IO) {
                            runCatching {
                                HttpCheck.run(target) { l -> scope.launch(Dispatchers.Main) { lines += l } }
                            }.onFailure { e -> scope.launch(Dispatchers.Main) { lines += "Error: ${e.javaClass.simpleName}: ${e.message}" } }
                        }
                    }
                },
                onStop = { job?.cancel() },
            )
            if (job?.isActive == true) LinearProgressIndicator(Modifier.fillMaxWidth())
        }
        Console(lines, Modifier.weight(1f))
    }
}
