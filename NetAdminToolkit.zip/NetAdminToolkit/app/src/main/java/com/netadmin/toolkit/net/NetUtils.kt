package com.netadmin.toolkit.net

import android.content.Context
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.Network
import android.net.NetworkCapabilities
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Big pool for blocking socket probes (LAN sweep, port scan). */
val ProbeDispatcher = Executors.newFixedThreadPool(128).asCoroutineDispatcher()

fun InetAddress.clean(): String = (hostAddress ?: "").substringBefore('%')

fun isIPv4Literal(s: String) = Regex("""^\d{1,3}(\.\d{1,3}){3}$""").matches(s.trim())
fun isIPv6Literal(s: String) = s.contains(':') && Regex("""^[0-9a-fA-F:.]+$""").matches(s.trim())

fun ipv6Scope(a: Inet6Address): String {
    val b0 = a.address[0].toInt() and 0xff
    return when {
        a.isLinkLocalAddress -> "link-local"
        a.isLoopbackAddress -> "loopback"
        (b0 and 0xfe) == 0xfc -> "ULA (private)"
        a.isMulticastAddress -> "multicast"
        else -> "global"
    }
}

fun macIsRandomized(mac: String): Boolean {
    val first = mac.split(':', '-').firstOrNull()?.toIntOrNull(16) ?: return false
    return (first and 0x02) != 0
}

fun bytesToMac(b: ByteArray?): String? =
    b?.takeIf { it.isNotEmpty() }?.joinToString(":") { "%02X".format(it) }

// ---------- IPv4 math ----------
fun ipToLong(ip: String): Long =
    ip.trim().split('.').fold(0L) { acc, p -> (acc shl 8) or (p.toLong() and 0xff) }

fun longToIp(v: Long): String =
    listOf(24, 16, 8, 0).joinToString(".") { ((v shr it) and 0xff).toString() }

fun prefixToMask(p: Int): Long = if (p <= 0) 0L else (0xFFFFFFFFL shl (32 - p)) and 0xFFFFFFFFL

fun maskToPrefix(mask: String): Int? {
    val m = ipToLong(mask)
    val p = java.lang.Long.bitCount(m)
    return if (prefixToMask(p) == m) p else null
}

// ---------- Active network helpers ----------
data class ActiveLink(
    val network: Network?,
    val lp: LinkProperties?,
    val caps: NetworkCapabilities?,
) {
    val ipv4: Inet4Address?
        get() = lp?.linkAddresses?.map { it.address }?.filterIsInstance<Inet4Address>()?.firstOrNull()
    val ipv4Prefix: Int?
        get() = lp?.linkAddresses?.firstOrNull { it.address is Inet4Address }?.prefixLength
    val gateway: String?
        get() = lp?.routes?.firstOrNull { it.isDefaultRoute && it.gateway is Inet4Address }?.gateway?.clean()
            ?: lp?.routes?.firstOrNull { it.isDefaultRoute }?.gateway?.clean()
    val dns: List<String> get() = lp?.dnsServers?.map { it.clean() } ?: emptyList()
}

fun Context.connectivity() = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

fun Context.activeLink(): ActiveLink {
    val cm = connectivity()
    val n = cm.activeNetwork
    return ActiveLink(n, n?.let { cm.getLinkProperties(it) }, n?.let { cm.getNetworkCapabilities(it) })
}

/** The local LAN (Wi-Fi or Ethernet) even if a VPN is the default network. */
@Suppress("DEPRECATION")
fun Context.lanLink(): ActiveLink {
    val cm = connectivity()
    for (n in cm.allNetworks) {
        val c = cm.getNetworkCapabilities(n) ?: continue
        if (c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) {
            val lp = cm.getLinkProperties(n)
            if (lp?.linkAddresses?.any { it.address is Inet4Address } == true) return ActiveLink(n, lp, c)
        }
    }
    return activeLink()
}

// ---------- Process helpers (ping / traceroute) ----------
/** Streams the output of a command line by line. Cancelling the coroutine kills the process. */
suspend fun runProcess(cmd: List<String>, onLine: (String) -> Unit): Int = coroutineScope {
    val p = withContext(Dispatchers.IO) { ProcessBuilder(cmd).redirectErrorStream(true).start() }
    val killer = launch(Dispatchers.IO) {
        try { awaitCancellation() } finally { p.destroy() }
    }
    try {
        withContext(Dispatchers.IO) {
            val r = p.inputStream.bufferedReader()
            while (true) {
                val line = r.readLine() ?: break
                withContext(Dispatchers.Main) { onLine(line) }
            }
            p.waitFor()
        }
    } finally {
        killer.cancel()
    }
}

/** Runs a short command and returns all output (blocking, call from IO). */
fun execCapture(cmd: List<String>, timeoutMs: Long = 5000): String {
    val p = ProcessBuilder(cmd).redirectErrorStream(true).start()
    val out = StringBuilder()
    val t = Thread { runCatching { p.inputStream.bufferedReader().forEachLine { out.appendLine(it) } } }
    t.start()
    if (!p.waitFor(timeoutMs, TimeUnit.MILLISECONDS)) p.destroy()
    t.join(500)
    return out.toString()
}

fun pingBinary(v6: Boolean) = if (v6) "/system/bin/ping6" else "/system/bin/ping"

val PING_TIME = Regex("""time[=<]([\d.]+)\s*ms""")

/** Single ICMP echo, returns RTT in ms or null. Blocking. */
fun pingOnce(ip: String, timeoutSec: Int = 1): Double? {
    val out = execCapture(listOf(pingBinary(ip.contains(':')), "-n", "-c", "1", "-W", "$timeoutSec", ip), timeoutSec * 1000L + 1500)
    return PING_TIME.find(out)?.groupValues?.get(1)?.toDoubleOrNull()
}

fun reverseDns(ip: String): String? = runCatching {
    val h = InetAddress.getByName(ip).canonicalHostName
    if (h == ip) null else h
}.getOrNull()
