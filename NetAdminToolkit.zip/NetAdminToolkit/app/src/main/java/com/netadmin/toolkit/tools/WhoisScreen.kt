package com.netadmin.toolkit.tools

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.netadmin.toolkit.ui.Console
import com.netadmin.toolkit.ui.RunStopButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

object Whois {
    fun query(server: String, q: String): String = Socket().use { s ->
        s.connect(InetSocketAddress(server, 43), 8000)
        s.soTimeout = 12000
        s.getOutputStream().apply { write("$q\r\n".toByteArray()); flush() }
        s.getInputStream().readBytes().toString(Charsets.UTF_8)
    }

    private val REFER = listOf(
        Regex("""(?im)^\s*refer:\s*(\S+)"""),
        Regex("""(?im)^\s*whois:\s*(\S+)"""),
        Regex("""(?im)^\s*Registrar WHOIS Server:\s*(\S+)"""),
        Regex("""(?im)^\s*ReferralServer:\s*(?:whois|rwhois)://([^\s:/]+)"""),
    )

    fun referral(resp: String, current: String): String? = REFER.firstNotNullOfOrNull { r ->
        r.find(resp)?.groupValues?.get(1)
            ?.removePrefix("http://")?.removePrefix("https://")?.trimEnd('/')
            ?.takeIf { it.isNotBlank() && !it.equals(current, true) }
    }

    fun normalize(input: String): String =
        input.trim().removePrefix("http://").removePrefix("https://").substringBefore('/').removePrefix("www.")
}

@Composable
fun WhoisScreen(initialHost: String) {
    val scope = rememberCoroutineScope()
    var target by rememberSaveable { mutableStateOf(initialHost.ifBlank { "example.com" }) }
    val lines = remember { mutableStateListOf<String>() }
    var job by remember { mutableStateOf<Job?>(null) }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            HostField(target, { target = it }, "Domain, IP or ASN (e.g. AS15169)")
            RunStopButton(
                running = job?.isActive == true, modifier = Modifier.fillMaxWidth(), runLabel = "Whois",
                onRun = {
                    lines.clear()
                    val q = Whois.normalize(target)
                    job = scope.launch {
                        var server = "whois.iana.org"
                        val seen = mutableSetOf<String>()
                        repeat(4) {
                            if (!seen.add(server.lowercase())) return@launch
                            lines += "──────── $server ────────"
                            val resp = withContext(Dispatchers.IO) {
                                runCatching {
                                    // ARIN wants "n + <ip>" for network records
                                    val query = if (server.contains("arin.net")) "n + $q" else q
                                    Whois.query(server, query)
                                }.getOrElse { "Error: ${it.message}" }
                            }
                            lines += resp.lines().filterNot { it.startsWith("%") && server.contains("iana") }
                            server = Whois.referral(resp, server) ?: return@launch
                        }
                    }
                },
                onStop = { job?.cancel() },
            )
            if (job?.isActive == true) LinearProgressIndicator(Modifier.fillMaxWidth())
        }
        Console(lines, Modifier.weight(1f))
    }
}
