package com.netadmin.toolkit.tools

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.netadmin.toolkit.net.activeLink
import com.netadmin.toolkit.net.isIPv4Literal
import com.netadmin.toolkit.net.isIPv6Literal
import com.netadmin.toolkit.ui.Console
import com.netadmin.toolkit.ui.RunStopButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.xbill.DNS.DClass
import org.xbill.DNS.Message
import org.xbill.DNS.Name
import org.xbill.DNS.Rcode
import org.xbill.DNS.Record
import org.xbill.DNS.ReverseMap
import org.xbill.DNS.Section
import org.xbill.DNS.SimpleResolver
import org.xbill.DNS.Type
import java.time.Duration

private val TYPES = listOf("A", "AAAA", "CNAME", "MX", "NS", "TXT", "SOA", "PTR", "SRV", "CAA", "DS", "DNSKEY", "ANY")
private val ALL_COMMON = listOf("A", "AAAA", "CNAME", "MX", "NS", "TXT", "SOA", "CAA")

object DnsTool {
    fun query(input: String, typeName: String, server: String, tcp: Boolean): List<String> {
        val type = Type.value(typeName)
        val isIp = isIPv4Literal(input) || isIPv6Literal(input)
        val name = if (isIp) ReverseMap.fromAddress(input)
        else Name.fromString(if (input.endsWith(".")) input else "$input.")
        val qtype = if (isIp) Type.PTR else type
        val query = Message.newQuery(Record.newRecord(name, qtype, DClass.IN))
        val res = SimpleResolver(server).apply {
            setTCP(tcp)
            setTimeout(Duration.ofSeconds(5))
        }
        val t0 = System.nanoTime()
        @Suppress("DEPRECATION")
        val resp = res.send(query)
        val ms = (System.nanoTime() - t0) / 1_000_000
        val out = mutableListOf<String>()
        out += ";; ${name} ${Type.string(qtype)} @${server} ${if (tcp) "TCP" else "UDP"}"
        out += ";; status: ${Rcode.string(resp.header.rcode)}, flags: ${resp.header.printFlags().trim()}, time: $ms ms"
        listOf(Section.ANSWER to "ANSWER", Section.AUTHORITY to "AUTHORITY", Section.ADDITIONAL to "ADDITIONAL")
            .forEach { (sec, label) ->
                val recs = resp.getSection(sec)
                if (recs.isNotEmpty()) {
                    out += ";; $label (${recs.size})"
                    recs.forEach { out += it.toString() }
                }
            }
        if (resp.getSection(Section.ANSWER).isEmpty()) out += ";; (no answer records)"
        return out
    }
}

@Composable
fun DnsScreen(initialHost: String) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val systemDns = remember { ctx.activeLink().dns.firstOrNull() ?: "8.8.8.8" }
    val servers = listOf("System" to systemDns, "Cloudflare" to "1.1.1.1", "Google" to "8.8.8.8", "Quad9" to "9.9.9.9")
    var domain by rememberSaveable { mutableStateOf("example.com") }
    LaunchedEffect(initialHost) {
        val h = initialHost.substringBefore('#')
        if (h.isNotBlank()) domain = h
    }
    var type by rememberSaveable { mutableStateOf("A") }
    var server by rememberSaveable { mutableStateOf(systemDns) }
    var custom by rememberSaveable { mutableStateOf("") }
    var tcp by rememberSaveable { mutableStateOf(false) }
    var all by rememberSaveable { mutableStateOf(false) }
    val lines = remember { mutableStateListOf<String>() }
    var job by remember { mutableStateOf<Job?>(null) }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            HostField(domain, { domain = it }, "Domain or IP (IP → PTR)")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selected = all, onClick = { all = !all }, label = { Text("All common") })
                TYPES.forEach { t ->
                    FilterChip(selected = !all && type == t, onClick = { type = t; all = false }, label = { Text(t) })
                }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                servers.forEach { (label, ip) ->
                    FilterChip(selected = server == ip && custom.isBlank(), onClick = { server = ip; custom = "" },
                        label = { Text("$label $ip") })
                }
                FilterChip(selected = tcp, onClick = { tcp = !tcp }, label = { Text("TCP") })
            }
            OutlinedTextField(
                value = custom, onValueChange = { custom = it.trim() }, singleLine = true,
                label = { Text("Custom DNS server (optional)") }, modifier = Modifier.fillMaxWidth(),
            )
            RunStopButton(
                running = job?.isActive == true, modifier = Modifier.fillMaxWidth(), runLabel = "Lookup",
                onRun = {
                    lines.clear()
                    val srv = custom.ifBlank { server }
                    val types = when {
                        isIPv4Literal(domain) || isIPv6Literal(domain) -> listOf("PTR")
                        all -> ALL_COMMON
                        else -> listOf(type)
                    }
                    job = scope.launch {
                        for (t in types) {
                            val res = withContext(Dispatchers.IO) {
                                runCatching { DnsTool.query(domain, t, srv, tcp) }
                                    .getOrElse { listOf(";; $t query failed: ${it.javaClass.simpleName}: ${it.message}") }
                            }
                            lines += res; lines += ""
                        }
                    }
                },
                onStop = { job?.cancel() },
            )
            Text("Tip: compare answers across servers to spot propagation or split-horizon issues.",
                style = MaterialTheme.typography.bodySmall)
        }
        Console(lines, Modifier.weight(1f))
    }
}
