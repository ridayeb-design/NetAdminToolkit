package com.netadmin.toolkit.net

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.net.ConnectException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket

data class LanHost(
    val ip: String,
    val latencyMs: Long?,
    val method: String,
    val hostname: String? = null,
    val netbios: String? = null,
    val mac: String? = null,
    val openPorts: List<Int> = emptyList(),
    val isGateway: Boolean = false,
    val isSelf: Boolean = false,
)

object LanScanner {
    private val PROBE_PORTS = listOf(80, 443, 22, 445, 139, 53, 8080, 554, 3389, 62078, 5000, 9100)

    /** Returns latency + method if the host answers ICMP or any TCP probe (open OR refused). */
    private fun probe(ip: String, timeout: Int): Pair<Long, String>? {
        val addr = InetAddress.getByName(ip)
        val t0 = System.currentTimeMillis()
        if (runCatching { addr.isReachable(timeout) }.getOrDefault(false))
            return (System.currentTimeMillis() - t0) to "ICMP"
        for (p in PROBE_PORTS.take(6)) {
            val t1 = System.currentTimeMillis()
            try {
                Socket().use { it.connect(InetSocketAddress(addr, p), timeout / 2) }
                return (System.currentTimeMillis() - t1) to "TCP/$p"
            } catch (e: ConnectException) {
                // RST = host is alive, port closed
                if (e.message?.contains("refused", true) == true) return (System.currentTimeMillis() - t1) to "TCP RST"
            } catch (_: Exception) {}
        }
        return null
    }

    private fun quickPorts(ip: String): List<Int> = PROBE_PORTS.filter { p ->
        runCatching { Socket().use { it.connect(InetSocketAddress(ip, p), 250) }; true }.getOrDefault(false)
    }

    /** NetBIOS NBSTAT query (UDP/137): returns name and MAC for Windows/Samba hosts. */
    fun netbios(ip: String): Pair<String, String?>? = runCatching {
        val q = ByteArray(50)
        q[0] = 0x13; q[1] = 0x37 // txn id
        q[5] = 1 // qdcount
        q[12] = 0x20
        // "*" padded with NULs, first-level encoded
        val name = ByteArray(16).also { it[0] = '*'.code.toByte() }
        for (i in 0 until 16) {
            val b = name[i].toInt() and 0xff
            q[13 + i * 2] = ('A'.code + (b shr 4)).toByte()
            q[14 + i * 2] = ('A'.code + (b and 0x0f)).toByte()
        }
        q[45] = 0; q[46] = 0; q[47] = 0x21; q[48] = 0; q[49] = 1
        DatagramSocket().use { s ->
            s.soTimeout = 700
            s.send(DatagramPacket(q, q.size, InetAddress.getByName(ip), 137))
            val buf = ByteArray(1024)
            val pkt = DatagramPacket(buf, buf.size)
            s.receive(pkt)
            val n = buf[56].toInt() and 0xff
            var hostName: String? = null
            for (i in 0 until n) {
                val off = 57 + i * 18
                val nm = String(buf, off, 15, Charsets.US_ASCII).trim()
                val suffix = buf[off + 15].toInt() and 0xff
                val group = (buf[off + 16].toInt() and 0x80) != 0
                if (suffix == 0 && !group) { hostName = nm; break }
            }
            val macOff = 57 + n * 18
            val mac = if (pkt.length >= macOff + 6)
                (0 until 6).joinToString(":") { "%02X".format(buf[macOff + it]) }.takeIf { it != "00:00:00:00:00:00" }
            else null
            hostName?.let { it to mac }
        }
    }.getOrNull()

    /** ARP/neighbour table (works on older Android; restricted on 10+). */
    fun neighbours(): Map<String, String> {
        val map = mutableMapOf<String, String>()
        runCatching {
            File("/proc/net/arp").readLines().drop(1).forEach { l ->
                val p = l.split(Regex("\\s+"))
                if (p.size >= 4 && p[3] != "00:00:00:00:00:00") map[p[0]] = p[3].uppercase()
            }
        }
        if (map.isEmpty()) runCatching {
            execCapture(listOf("ip", "neigh", "show"), 2000).lines().forEach { l ->
                val m = Regex("""^(\d+\.\d+\.\d+\.\d+) .*lladdr ([0-9a-fA-F:]{17})""").find(l)
                if (m != null) map[m.groupValues[1]] = m.groupValues[2].uppercase()
            }
        }
        return map
    }

    /**
     * Sweeps [start..end] (inclusive, as longs). Calls [onFound] for each live host and
     * [onProgress] with the count of probed addresses.
     */
    suspend fun scan(
        start: Long, end: Long, selfIp: String?, gateway: String?,
        timeout: Int = 600, concurrency: Int = 64,
        onProgress: (Int) -> Unit, onFound: (LanHost) -> Unit, onUpdate: (LanHost) -> Unit,
    ) = coroutineScope {
        val sem = Semaphore(concurrency)
        var done = 0
        val found = mutableListOf<LanHost>()
        val jobs = (start..end).map { v ->
            val ip = longToIp(v)
            async(ProbeDispatcher) {
                sem.withPermit {
                    val r = if (ip == selfIp) 0L to "self" else probe(ip, timeout)
                    withContext(kotlinx.coroutines.Dispatchers.Main) {
                        done++; onProgress(done)
                        if (r != null) {
                            val h = LanHost(ip, r.first, r.second, isGateway = ip == gateway, isSelf = ip == selfIp)
                            found += h; onFound(h)
                        }
                    }
                }
            }
        }
        jobs.awaitAll()

        // Enrichment pass: names, MACs, a few open ports.
        val arp = withContext(ProbeDispatcher) { neighbours() }
        found.toList().map { h ->
            launch(ProbeDispatcher) {
                sem.withPermit {
                    val d = CompletableDeferred<String?>()
                    Thread { d.complete(reverseDns(h.ip)) }.start()
                    val rdns = withTimeoutOrNull(2500) { d.await() }
                    val nb = netbios(h.ip)
                    val ports = if (h.isSelf) emptyList() else quickPorts(h.ip)
                    val updated = h.copy(
                        hostname = rdns, netbios = nb?.first,
                        mac = arp[h.ip] ?: nb?.second, openPorts = ports,
                    )
                    withContext(kotlinx.coroutines.Dispatchers.Main) { onUpdate(updated) }
                }
            }
        }.forEach { it.join() }
    }
}
