package com.netadmin.toolkit.tools

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.netadmin.toolkit.net.clean
import com.netadmin.toolkit.net.ipToLong
import com.netadmin.toolkit.net.lanLink
import com.netadmin.toolkit.net.longToIp
import com.netadmin.toolkit.net.prefixToMask
import com.netadmin.toolkit.ui.InfoCard
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress

object Wol {
    fun parseMac(s: String): ByteArray? {
        val hex = s.filter { it.isLetterOrDigit() }
        if (hex.length != 12 || !hex.all { it.isDigit() || it.lowercaseChar() in 'a'..'f' }) return null
        return ByteArray(6) { hex.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
    }

    fun send(mac: ByteArray, target: String, port: Int) {
        val pkt = ByteArray(6 + 16 * 6)
        for (i in 0 until 6) pkt[i] = 0xFF.toByte()
        for (r in 0 until 16) System.arraycopy(mac, 0, pkt, 6 + r * 6, 6)
        DatagramSocket().use { s ->
            s.broadcast = true
            val addr = InetAddress.getByName(target)
            repeat(3) { s.send(DatagramPacket(pkt, pkt.size, addr, port)) }
        }
    }
}

private const val PREFS = "wol_devices"

private fun loadSaved(ctx: Context): List<Triple<String, String, String>> =
    ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getStringSet("list", emptySet()).orEmpty()
        .mapNotNull { e -> e.split('|').takeIf { it.size == 3 }?.let { Triple(it[0], it[1], it[2]) } }
        .sortedBy { it.first.lowercase() }

private fun saveAll(ctx: Context, list: List<Triple<String, String, String>>) =
    ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        .putStringSet("list", list.map { "${it.first}|${it.second}|${it.third}" }.toSet()).apply()

@Composable
fun WolScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val defaultBcast = remember {
        val l = ctx.lanLink()
        val ip = l.ipv4?.clean()
        if (ip != null) {
            val m = prefixToMask(l.ipv4Prefix ?: 24)
            longToIp((ipToLong(ip) and m) or (m.inv() and 0xFFFFFFFFL))
        } else "255.255.255.255"
    }
    var name by rememberSaveable { mutableStateOf("") }
    var mac by rememberSaveable { mutableStateOf("") }
    var target by rememberSaveable { mutableStateOf(defaultBcast) }
    var port by rememberSaveable { mutableStateOf("9") }
    var msg by remember { mutableStateOf<String?>(null) }
    val saved = remember { mutableStateListOf<Triple<String, String, String>>().apply { addAll(loadSaved(ctx)) } }

    fun wake(m: String, t: String) {
        val bytes = Wol.parseMac(m) ?: run { msg = "Invalid MAC address"; return }
        scope.launch {
            msg = withContext(Dispatchers.IO) {
                runCatching { Wol.send(bytes, t, port.toIntOrNull() ?: 9); "Magic packet sent to $m via $t:${port}" }
                    .getOrElse { "Failed: ${it.message}" }
            }
        }
    }

    LazyColumn(Modifier.fillMaxSize()) {
        item {
            InfoCard("Wake-on-LAN", Icons.Default.PowerSettingsNew) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(mac, { mac = it.trim() }, label = { Text("MAC (AA:BB:CC:DD:EE:FF)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(target, { target = it.trim() }, label = { Text("Broadcast / host") }, singleLine = true, modifier = Modifier.weight(1f))
                        NumField(port, { port = it }, "Port", Modifier.weight(0.4f))
                    }
                    OutlinedTextField(name, { name = it }, label = { Text("Name (to save)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { wake(mac, target) }) { Text("Wake") }
                        OutlinedButton(onClick = {
                            if (Wol.parseMac(mac) == null) { msg = "Invalid MAC address"; return@OutlinedButton }
                            saved.removeAll { it.second.equals(mac, true) }
                            saved.add(Triple(name.ifBlank { mac }, mac.uppercase(), target))
                            saveAll(ctx, saved); msg = "Saved"
                        }) { Text("Save device") }
                    }
                    msg?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                }
            }
        }
        items(saved, key = { it.second }) { d ->
            ListItem(
                headlineContent = { Text(d.first) },
                supportingContent = { Text("${d.second} → ${d.third}") },
                leadingContent = {
                    IconButton(onClick = { wake(d.second, d.third) }) { Icon(Icons.Default.PowerSettingsNew, "Wake") }
                },
                trailingContent = {
                    IconButton(onClick = { saved.remove(d); saveAll(ctx, saved) }) { Icon(Icons.Default.Delete, "Delete") }
                },
                modifier = Modifier.padding(horizontal = 4.dp),
            )
        }
    }
}
