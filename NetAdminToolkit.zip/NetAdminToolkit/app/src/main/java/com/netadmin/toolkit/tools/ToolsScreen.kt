package com.netadmin.toolkit.tools

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Https
import androidx.compose.material.icons.filled.NetworkPing
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Route
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.TravelExplore
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector

data class ToolEntry(val route: String, val title: String, val desc: String, val icon: ImageVector)

val TOOLS = listOf(
    ToolEntry("ping", "Ping", "ICMP echo with live stats (IPv4/IPv6)", Icons.Default.NetworkPing),
    ToolEntry("traceroute", "Traceroute", "Hop-by-hop path with RTT and reverse DNS", Icons.Default.Route),
    ToolEntry("dns", "DNS lookup", "A, AAAA, MX, TXT, NS, SOA, PTR, SRV, CAA… any server", Icons.Default.Dns),
    ToolEntry("whois", "Whois", "Domain & IP registration with referral following", Icons.Default.TravelExplore),
    ToolEntry("portscan", "Port scanner", "TCP connect scan with banner grabbing", Icons.Default.Security),
    ToolEntry("http", "HTTP / TLS check", "Status, headers, timings, certificate chain & expiry", Icons.Default.Https),
    ToolEntry("subnet", "Subnet calculator", "CIDR, masks, ranges, splitting", Icons.Default.Calculate),
    ToolEntry("wol", "Wake-on-LAN", "Send magic packets to wake hosts", Icons.Default.PowerSettingsNew),
)

@Composable
fun ToolsScreen(open: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize()) {
        items(TOOLS, key = { it.route }) { t ->
            ListItem(
                modifier = Modifier.clickable { open(t.route) },
                leadingContent = { Icon(t.icon, null, tint = MaterialTheme.colorScheme.primary) },
                headlineContent = { Text(t.title) },
                supportingContent = { Text(t.desc) },
            )
            HorizontalDivider()
        }
    }
}
