package com.netadmin.toolkit.tools

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CallSplit
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.netadmin.toolkit.net.clean
import com.netadmin.toolkit.net.ipToLong
import com.netadmin.toolkit.net.isIPv4Literal
import com.netadmin.toolkit.net.lanLink
import com.netadmin.toolkit.net.longToIp
import com.netadmin.toolkit.net.maskToPrefix
import com.netadmin.toolkit.net.prefixToMask
import com.netadmin.toolkit.ui.InfoCard
import com.netadmin.toolkit.ui.InfoSection
import com.netadmin.toolkit.ui.KV
import com.netadmin.toolkit.ui.SectionCard

object Subnet {
    /** Accepts "10.0.0.5/24", "10.0.0.5 255.255.255.0", "10.0.0.5/255.255.255.0". Returns ip,prefix. */
    fun parse(s: String): Pair<Long, Int>? {
        val parts = s.trim().split('/', ' ').filter { it.isNotBlank() }
        if (parts.isEmpty() || !isIPv4Literal(parts[0])) return null
        if (parts[0].split('.').any { it.toInt() > 255 }) return null
        val ip = ipToLong(parts[0])
        val p = when {
            parts.size == 1 -> 32
            isIPv4Literal(parts[1]) -> maskToPrefix(parts[1]) ?: return null
            else -> parts[1].toIntOrNull()?.takeIf { it in 0..32 } ?: return null
        }
        return ip to p
    }

    private fun bin(v: Long) = (0..3).joinToString(".") { i ->
        ((v shr (24 - i * 8)) and 0xff).toString(2).padStart(8, '0')
    }

    private fun kind(ip: Long): String {
        fun inNet(n: String, p: Int) = (ip and prefixToMask(p)) == ipToLong(n)
        return when {
            inNet("10.0.0.0", 8) || inNet("172.16.0.0", 12) || inNet("192.168.0.0", 16) -> "Private (RFC 1918)"
            inNet("100.64.0.0", 10) -> "Shared / CGNAT (RFC 6598)"
            inNet("127.0.0.0", 8) -> "Loopback"
            inNet("169.254.0.0", 16) -> "Link-local (APIPA)"
            inNet("224.0.0.0", 4) -> "Multicast"
            inNet("240.0.0.0", 4) -> "Reserved"
            inNet("192.0.2.0", 24) || inNet("198.51.100.0", 24) || inNet("203.0.113.0", 24) -> "Documentation"
            else -> "Public"
        }
    }

    private fun cls(ip: Long): String = when ((ip shr 24).toInt()) {
        in 0..127 -> "A"; in 128..191 -> "B"; in 192..223 -> "C"; in 224..239 -> "D (multicast)"; else -> "E"
    }

    fun calc(ip: Long, p: Int): InfoSection {
        val mask = prefixToMask(p)
        val wild = mask.inv() and 0xFFFFFFFFL
        val net = ip and mask
        val bc = net or wild
        val size = 1L shl (32 - p)
        val (first, last, usable) = when (p) {
            32 -> Triple(net, net, 1L)
            31 -> Triple(net, bc, 2L)
            else -> Triple(net + 1, bc - 1, size - 2)
        }
        return InfoSection("Result", listOf(
            "Address" to longToIp(ip),
            "CIDR" to "${longToIp(net)}/$p",
            "Netmask" to longToIp(mask),
            "Wildcard (ACL)" to longToIp(wild),
            "Network" to longToIp(net),
            "Broadcast" to longToIp(bc),
            "First host" to longToIp(first),
            "Last host" to longToIp(last),
            "Usable hosts" to "%,d".format(usable),
            "Total addresses" to "%,d".format(size),
            "Class" to cls(ip),
            "Type" to kind(ip),
            "Reverse zone" to longToIp(net).split('.').let { o ->
                val keep = (p / 8).coerceIn(1, 3); o.take(keep).reversed().joinToString(".") + ".in-addr.arpa"
            },
            "Mask (binary)" to bin(mask),
            "IP (binary)" to bin(ip),
            "Hex" to "0x%08X".format(ip),
        ))
    }
}

@Composable
fun SubnetScreen() {
    val ctx = LocalContext.current
    val default = rememberSaveable {
        val l = ctx.lanLink(); l.ipv4?.let { "${it.clean()}/${l.ipv4Prefix ?: 24}" } ?: "192.168.1.10/24"
    }
    var input by rememberSaveable { mutableStateOf(default) }
    var split by rememberSaveable { mutableStateOf("") }
    val parsed = Subnet.parse(input)

    LazyColumn(Modifier.fillMaxSize()) {
        item {
            InfoCard("IPv4 subnet calculator", Icons.Default.Calculate) {
                androidx.compose.material3.OutlinedTextField(
                    value = input, onValueChange = { input = it }, singleLine = true,
                    label = { Text("IP/prefix or IP mask") }, modifier = Modifier.fillMaxWidth(),
                )
                if (parsed == null) Text("Enter e.g. 10.20.30.40/22 or 10.20.30.40 255.255.252.0",
                    color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
        }
        if (parsed != null) {
            val (ip, p) = parsed
            item { SectionCard(Subnet.calc(ip, p)) }
            item {
                InfoCard("Split into smaller subnets", Icons.Default.CallSplit) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        NumField(split, { split = it.filter(Char::isDigit) }, "New prefix (> /$p)", Modifier.width(170.dp))
                    }
                    val np = split.toIntOrNull()
                    if (np != null && np in (p + 1)..32) {
                        val n = 1L shl (np - p)
                        val net = ip and prefixToMask(p)
                        val step = 1L shl (32 - np)
                        Text("$n subnets of /$np (${if (np >= 31) step else step - 2} hosts each)",
                            style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 6.dp))
                        (0 until minOf(n, 256L)).forEach { i ->
                            val s = net + i * step
                            KV("#${i + 1}", "${longToIp(s)}/$np  →  ${longToIp(s + step - 1)}")
                        }
                        if (n > 256) Text("… showing first 256", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        item { androidx.compose.foundation.layout.Spacer(Modifier.fillMaxWidth().padding(bottom = 24.dp)) }
    }
}
