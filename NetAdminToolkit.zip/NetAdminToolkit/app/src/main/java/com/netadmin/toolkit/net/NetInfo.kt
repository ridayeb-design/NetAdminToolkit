package com.netadmin.toolkit.net

import android.content.Context
import android.net.NetworkCapabilities as NC
import android.os.Build
import android.telephony.TelephonyManager
import com.netadmin.toolkit.ui.InfoSection
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.NetworkInterface
import java.net.URL

object NetInfo {

    fun transports(c: NC?): String {
        if (c == null) return "No network"
        val t = buildList {
            if (c.hasTransport(NC.TRANSPORT_WIFI)) add("Wi-Fi")
            if (c.hasTransport(NC.TRANSPORT_CELLULAR)) add("Cellular")
            if (c.hasTransport(NC.TRANSPORT_ETHERNET)) add("Ethernet")
            if (c.hasTransport(NC.TRANSPORT_VPN)) add("VPN")
            if (c.hasTransport(NC.TRANSPORT_BLUETOOTH)) add("Bluetooth")
        }
        return t.joinToString(" + ").ifEmpty { "Other" }
    }

    /** Local (on-device) info grouped by layer. No network calls. */
    @Suppress("DEPRECATION")
    fun collect(ctx: Context): List<InfoSection> {
        val cm = ctx.connectivity()
        val link = ctx.activeLink()
        val lp = link.lp
        val caps = link.caps
        val out = mutableListOf<InfoSection>()

        // ---- Summary
        out += InfoSection("Active connection", buildList {
            add("Transport" to transports(caps))
            add("Interface" to (lp?.interfaceName ?: "—"))
            if (caps?.hasTransport(NC.TRANSPORT_CELLULAR) == true) {
                val tm = ctx.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
                add("Carrier" to (tm.networkOperatorName.ifBlank { "—" }))
                add("SIM operator" to (tm.simOperatorName.ifBlank { "—" }))
                add("MCC/MNC" to (tm.networkOperator.ifBlank { "—" }))
            }
        })

        // ---- L1/L2
        val nif = lp?.interfaceName?.let { runCatching { NetworkInterface.getByName(it) }.getOrNull() }
        val mac = runCatching { bytesToMac(nif?.hardwareAddress) }.getOrNull()
        out += InfoSection("Link layer (L1/L2)", buildList {
            add("MAC address" to (mac?.let { if (macIsRandomized(it)) "$it (randomized)" else it }
                ?: "Hidden by Android 11+"))
            val mtu = if (Build.VERSION.SDK_INT >= 29) lp?.mtu?.takeIf { it > 0 } else null
            add("MTU" to ((mtu ?: runCatching { nif?.mtu }.getOrNull())?.toString() ?: "—"))
            caps?.let {
                add("Est. downlink" to "${it.linkDownstreamBandwidthKbps / 1000.0} Mbps")
                add("Est. uplink" to "${it.linkUpstreamBandwidthKbps / 1000.0} Mbps")
                if (Build.VERSION.SDK_INT >= 29 && it.signalStrength != Int.MIN_VALUE)
                    add("Signal strength" to "${it.signalStrength}")
            }
        })

        // ---- L3
        val v4 = lp?.linkAddresses?.filter { it.address is Inet4Address }.orEmpty()
        val v6 = lp?.linkAddresses?.filter { it.address is Inet6Address }.orEmpty()
        out += InfoSection("Network layer (L3) — IPv4", buildList {
            v4.forEach { la ->
                val ip = la.address.clean()
                add("Address" to "$ip/${la.prefixLength}")
                val mask = prefixToMask(la.prefixLength)
                add("Netmask" to longToIp(mask))
                add("Network" to "${longToIp(ipToLong(ip) and mask)}/${la.prefixLength}")
                add("Broadcast" to longToIp((ipToLong(ip) and mask) or (mask.inv() and 0xFFFFFFFFL)))
            }
            if (v4.isEmpty()) add("Address" to "none")
            add("Default gateway" to (lp?.routes?.filter { it.isDefaultRoute && it.gateway is Inet4Address }
                ?.joinToString { it.gateway!!.clean() }?.ifEmpty { "—" } ?: "—"))
            if (Build.VERSION.SDK_INT >= 30) add("DHCP server" to (lp?.dhcpServerAddress?.clean() ?: "—"))
        })
        out += InfoSection("Network layer (L3) — IPv6", buildList {
            v6.forEach { la ->
                val a = la.address as Inet6Address
                val temp = if ((la.flags and 0x01) != 0) ", temporary" else ""
                add(ipv6Scope(a) + temp to "${a.clean()}/${la.prefixLength}")
            }
            if (v6.isEmpty()) add("Address" to "none")
            add("Default gateway" to (lp?.routes?.filter { it.isDefaultRoute && it.gateway is Inet6Address }
                ?.joinToString { it.gateway!!.clean() }?.ifEmpty { "—" } ?: "—"))
            if (Build.VERSION.SDK_INT >= 30) lp?.nat64Prefix?.let { add("NAT64 prefix" to it.toString()) }
        })

        out += InfoSection("Routing table", lp?.routes?.map { r ->
            val gw = r.gateway?.clean()?.takeIf { it != "0.0.0.0" && it != "::" } ?: "on-link"
            r.destination.toString() to "via $gw ${r.`interface` ?: ""}".trim()
        }.orEmpty().ifEmpty { listOf("Routes" to "none") })

        // ---- DNS / app layer config
        out += InfoSection("DNS & proxy", buildList {
            lp?.dnsServers?.forEachIndexed { i, d -> add("DNS ${i + 1}" to d.clean()) }
            if (lp?.dnsServers.isNullOrEmpty()) add("DNS" to "none")
            add("Search domains" to (lp?.domains ?: "—"))
            if (Build.VERSION.SDK_INT >= 28) {
                add("Private DNS (DoT)" to when {
                    lp?.isPrivateDnsActive != true -> "Off"
                    lp?.privateDnsServerName != null -> "On — ${lp?.privateDnsServerName}"
                    else -> "On — automatic"
                })
            }
            val proxy = lp?.httpProxy
            add("HTTP proxy" to when {
                proxy == null -> "None"
                proxy.pacFileUrl != null && proxy.pacFileUrl.toString().isNotBlank() && proxy.pacFileUrl.toString() != "null" -> "PAC: ${proxy.pacFileUrl}"
                else -> "${proxy.host}:${proxy.port}"
            })
        })

        // ---- Capabilities
        caps?.let { c ->
            fun yn(b: Boolean) = if (b) "Yes" else "No"
            out += InfoSection("Network capabilities", buildList {
                add("Internet" to yn(c.hasCapability(NC.NET_CAPABILITY_INTERNET)))
                add("Validated" to yn(c.hasCapability(NC.NET_CAPABILITY_VALIDATED)))
                add("Captive portal" to yn(c.hasCapability(NC.NET_CAPABILITY_CAPTIVE_PORTAL)))
                add("Metered" to yn(!c.hasCapability(NC.NET_CAPABILITY_NOT_METERED)))
                add("VPN active" to yn(!c.hasCapability(NC.NET_CAPABILITY_NOT_VPN)))
                if (Build.VERSION.SDK_INT >= 28) add("Roaming" to yn(!c.hasCapability(NC.NET_CAPABILITY_NOT_ROAMING)))
            })
        }

        // ---- All known networks
        val others = cm.allNetworks.mapNotNull { n ->
            val c = cm.getNetworkCapabilities(n) ?: return@mapNotNull null
            val l = cm.getLinkProperties(n)
            val addrs = l?.linkAddresses?.joinToString { "${it.address.clean()}/${it.prefixLength}" } ?: ""
            "${transports(c)} (${l?.interfaceName ?: "?"})" to addrs.ifEmpty { "no address" }
        }
        if (others.isNotEmpty()) out += InfoSection("All networks", others)

        // ---- Raw interfaces
        val ifaces = runCatching {
            NetworkInterface.getNetworkInterfaces()?.toList().orEmpty()
                .filter { it.inetAddresses.hasMoreElements() }
                .map { ni ->
                    val state = if (ni.isUp) "UP" else "DOWN"
                    val addrs = ni.interfaceAddresses.joinToString("\n") { "${it.address.clean()}/${it.networkPrefixLength}" }
                    "${ni.name} [$state, mtu ${runCatching { ni.mtu }.getOrDefault(0)}]" to addrs
                }
        }.getOrDefault(emptyList())
        if (ifaces.isNotEmpty()) out += InfoSection("Interfaces", ifaces)

        return out
    }

    private fun httpGet(url: String, timeout: Int = 6000): String? = runCatching {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = timeout; c.readTimeout = timeout
        c.setRequestProperty("User-Agent", "NetAdminToolkit/1.0")
        c.setRequestProperty("Accept", "application/json")
        c.inputStream.bufferedReader().use { it.readText() }.also { c.disconnect() }
    }.getOrNull()

    /** Public / Internet-facing info. Network call, run on IO. */
    fun publicInfo(): InfoSection {
        val rows = mutableListOf<Pair<String, String>>()
        val json = httpGet("https://ipinfo.io/json")?.let { runCatching { JSONObject(it) }.getOrNull() }
        if (json != null) {
            rows += "Public IPv4" to json.optString("ip", "—")
            json.optString("hostname").takeIf { it.isNotBlank() }?.let { rows += "Reverse DNS" to it }
            rows += "ISP / ASN" to json.optString("org", "—")
            rows += "Location" to listOf(json.optString("city"), json.optString("region"), json.optString("country"))
                .filter { it.isNotBlank() }.joinToString(", ").ifEmpty { "—" }
            rows += "Timezone" to json.optString("timezone", "—")
        } else {
            rows += "Public IPv4" to (httpGet("https://api.ipify.org")?.trim() ?: "unreachable")
        }
        rows += "Public IPv6" to (httpGet("https://api6.ipify.org", 4000)?.trim() ?: "none / no IPv6 connectivity")
        return InfoSection("Internet / public", rows)
    }
}
