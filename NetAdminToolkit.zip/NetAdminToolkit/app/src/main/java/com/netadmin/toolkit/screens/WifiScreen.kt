package com.netadmin.toolkit.screens

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SettingsInputAntenna
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiFind
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.netadmin.toolkit.net.WifiUtil
import com.netadmin.toolkit.ui.Hint
import com.netadmin.toolkit.ui.InfoCard
import com.netadmin.toolkit.ui.SectionCard
import kotlinx.coroutines.delay

private fun hasLocation(ctx: Context) =
    ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

private fun locationOn(ctx: Context): Boolean {
    val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    return if (Build.VERSION.SDK_INT >= 28) lm.isLocationEnabled
    else lm.isProviderEnabled(LocationManager.GPS_PROVIDER) || lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
}

@Composable
fun WifiScreen() {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(hasLocation(ctx)) }
    var tick by remember { mutableIntStateOf(0) }
    var sections by remember { mutableStateOf(WifiUtil.sections(ctx)) }
    var aps by remember { mutableStateOf(WifiUtil.scanResults(ctx)) }
    var scanMsg by remember { mutableStateOf<String?>(null) }
    val rssiHistory = remember { mutableStateListOf<Int>() }
    var currentRssi by remember { mutableIntStateOf(0) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasLocation(ctx); tick++
    }

    // Live refresh: RSSI graph every second, full details every 5 s.
    LaunchedEffect(granted) {
        var n = 0
        while (true) {
            val wi = WifiUtil.connection(ctx)
            val r = wi?.rssi ?: -127
            if (r > -127) {
                currentRssi = r
                rssiHistory.add(r); if (rssiHistory.size > 90) rssiHistory.removeAt(0)
            }
            if (n++ % 5 == 0) sections = WifiUtil.sections(ctx)
            delay(1000)
        }
    }
    LaunchedEffect(tick) { sections = WifiUtil.sections(ctx); aps = WifiUtil.scanResults(ctx) }

    DisposableEffect(Unit) {
        val rx = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                aps = WifiUtil.scanResults(ctx)
                scanMsg = "${aps.size} access points"
            }
        }
        ContextCompat.registerReceiver(
            ctx, rx, IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION), ContextCompat.RECEIVER_EXPORTED,
        )
        onDispose { runCatching { ctx.unregisterReceiver(rx) } }
    }

    LazyColumn(Modifier.fillMaxSize()) {
        if (!granted || !locationOn(ctx)) item {
            InfoCard("Permission needed", Icons.Default.WifiFind) {
                Text(
                    "Android only reveals SSID, BSSID and nearby networks when Location permission is granted " +
                        "and Location is turned on. Nothing is collected or sent anywhere.",
                    style = MaterialTheme.typography.bodyMedium,
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (!granted) Button(onClick = {
                        val perms = buildList {
                            add(Manifest.permission.ACCESS_FINE_LOCATION)
                            add(Manifest.permission.ACCESS_COARSE_LOCATION)
                            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.NEARBY_WIFI_DEVICES)
                        }
                        launcher.launch(perms.toTypedArray())
                    }) { Text("Grant") }
                    if (!locationOn(ctx)) FilledTonalButton(onClick = {
                        ctx.startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }) { Text("Turn on Location") }
                }
            }
        }

        item {
            InfoCard("Signal — live (${currentRssi} dBm)", Icons.Default.ShowChart) {
                RssiGraph(rssiHistory)
                Text(
                    "Last 90 s. Green ≥ −60, amber ≥ −70, red below. Walk around to survey coverage.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        items(sections, key = { it.title }) { s ->
            SectionCard(s, when (s.title) { "Radio" -> Icons.Default.SettingsInputAntenna; "DHCP lease" -> Icons.Default.Router; else -> Icons.Default.Wifi })
        }

        item {
            InfoCard("Nearby networks", Icons.Default.Search) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        @Suppress("DEPRECATION")
                        val ok = WifiUtil.manager(ctx).startScan()
                        scanMsg = if (ok) "Scanning…" else "Scan throttled by Android (4 scans / 2 min). Showing cached results."
                        aps = WifiUtil.scanResults(ctx)
                    }) { Text("Scan") }
                }
                scanMsg?.let { Text(it, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp)) }
                if (aps.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    ChannelUsage(aps)
                }
            }
        }
        items(aps, key = { it.bssid + it.freq }) { ap -> ApRow(ap) }
        item { Hint("Tip: turn off “Wi-Fi scan throttling” in Developer options for unlimited rescans."); Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun RssiGraph(values: List<Int>) {
    val good = androidx.compose.ui.graphics.Color(0xFF4CAF50)
    val mid = androidx.compose.ui.graphics.Color(0xFFFFB300)
    val bad = androidx.compose.ui.graphics.Color(0xFFE53935)
    val grid = MaterialTheme.colorScheme.outlineVariant
    Canvas(Modifier.fillMaxWidth().height(120.dp).padding(vertical = 6.dp)) {
        val top = -30f; val bottom = -100f
        fun y(v: Int) = size.height * ((top - v) / (top - bottom)).coerceIn(0f, 1f)
        listOf(-50, -60, -70, -80, -90).forEach { g ->
            drawLine(grid, Offset(0f, y(g)), Offset(size.width, y(g)), strokeWidth = 1f)
        }
        if (values.size < 2) return@Canvas
        val step = size.width / 89f
        val path = Path()
        values.forEachIndexed { i, v ->
            val x = i * step
            if (i == 0) path.moveTo(x, y(v)) else path.lineTo(x, y(v))
        }
        val last = values.last()
        drawPath(path, if (last >= -60) good else if (last >= -70) mid else bad, style = Stroke(width = 4f))
    }
}

@Composable
private fun ChannelUsage(aps: List<WifiUtil.Ap>) {
    val byBand = aps.groupBy { WifiUtil.band(it.freq) }
    byBand.toSortedMap().forEach { (band, list) ->
        val counts = list.groupingBy { WifiUtil.channel(it.freq) }.eachCount().toSortedMap()
        Text("$band channel usage", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
        Text(
            counts.entries.joinToString("  ") { "ch${it.key}:${it.value}" },
            fontFamily = FontFamily.Monospace,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(bottom = 6.dp),
        )
    }
}

@Composable
private fun ApRow(ap: WifiUtil.Ap) {
    val color = when {
        ap.rssi >= -60 -> androidx.compose.ui.graphics.Color(0xFF4CAF50)
        ap.rssi >= -70 -> androidx.compose.ui.graphics.Color(0xFFFFB300)
        else -> androidx.compose.ui.graphics.Color(0xFFE53935)
    }
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
        Row {
            Text(ap.ssid, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
            Text("${ap.rssi} dBm", color = color, fontFamily = FontFamily.Monospace)
        }
        Text(
            "${ap.bssid}  ·  ch ${WifiUtil.channel(ap.freq)} (${WifiUtil.band(ap.freq)}, ${ap.width})  ·  ${ap.security}" +
                (ap.standard?.let { "  ·  $it" } ?: ""),
            style = MaterialTheme.typography.bodySmall,
            fontFamily = FontFamily.Monospace,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.width(1.dp))
        HorizontalDivider(Modifier.padding(top = 6.dp), color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
    }
}
