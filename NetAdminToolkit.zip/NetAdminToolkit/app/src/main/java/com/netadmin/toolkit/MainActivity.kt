package com.netadmin.toolkit

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Lan
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.netadmin.toolkit.screens.LanScreen
import com.netadmin.toolkit.screens.OverviewScreen
import com.netadmin.toolkit.screens.WifiScreen
import com.netadmin.toolkit.tools.DnsScreen
import com.netadmin.toolkit.tools.HttpScreen
import com.netadmin.toolkit.tools.PingScreen
import com.netadmin.toolkit.tools.PortScanScreen
import com.netadmin.toolkit.tools.SubnetScreen
import com.netadmin.toolkit.tools.TOOLS
import com.netadmin.toolkit.tools.ToolsScreen
import com.netadmin.toolkit.tools.TracerouteScreen
import com.netadmin.toolkit.tools.WhoisScreen
import com.netadmin.toolkit.tools.WolScreen
import com.netadmin.toolkit.ui.NetTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { NetTheme { AppRoot() } }
    }
}

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val TABS = listOf(
    Tab("overview", "IP info", Icons.Default.Hub),
    Tab("wifi", "Wi-Fi", Icons.Default.Wifi),
    Tab("lan", "LAN", Icons.Default.Lan),
    Tab("tools", "Tools", Icons.Default.Build),
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot() {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route ?: "overview"
    val base = route.substringBefore('?')
    val tab = TABS.firstOrNull { it.route == base }
    val tool = TOOLS.firstOrNull { it.route == base }

    fun openTool(r: String) = nav.navigate(r)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(tool?.title ?: tab?.let { if (it.route == "overview") "NetAdmin Toolkit" else it.label } ?: "") },
                navigationIcon = {
                    if (tab == null) IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
            )
        },
        bottomBar = {
            NavigationBar {
                TABS.forEach { t ->
                    NavigationBarItem(
                        selected = tab?.route == t.route || (tab == null && t.route == "tools"),
                        onClick = {
                            nav.navigate(t.route) {
                                popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(t.icon, null) },
                        label = { Text(t.label) },
                    )
                }
            }
        },
    ) { pad ->
        NavHost(nav, startDestination = "overview", modifier = Modifier.padding(pad)) {
            composable("overview") { OverviewScreen() }
            composable("wifi") { WifiScreen() }
            composable("lan") { LanScreen(::openTool) }
            composable("tools") { ToolsScreen(::openTool) }

            fun hostTool(name: String, content: @Composable (String) -> Unit) =
                composable(
                    "$name?host={host}",
                    arguments = listOf(navArgument("host") { type = NavType.StringType; defaultValue = "" }),
                ) { e -> content(e.arguments?.getString("host").orEmpty()) }

            hostTool("ping") { PingScreen(it) }
            hostTool("traceroute") { TracerouteScreen(it) }
            hostTool("dns") { DnsScreen(it) }
            hostTool("whois") { WhoisScreen(it) }
            hostTool("portscan") { PortScanScreen(it) }
            hostTool("http") { HttpScreen(it) }
            composable("subnet") { SubnetScreen() }
            composable("wol") { WolScreen() }
        }
    }
}
