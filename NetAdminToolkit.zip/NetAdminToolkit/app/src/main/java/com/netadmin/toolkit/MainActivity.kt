package com.netadmin.toolkit

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.netadmin.toolkit.screens.LanScreen
import com.netadmin.toolkit.screens.OverviewScreen
import com.netadmin.toolkit.screens.WifiScreen
import com.netadmin.toolkit.tools.DnsScreen
import com.netadmin.toolkit.tools.HttpScreen
import com.netadmin.toolkit.tools.PingScreen
import com.netadmin.toolkit.tools.PortScanScreen
import com.netadmin.toolkit.tools.SubnetScreen
import com.netadmin.toolkit.tools.TracerouteScreen
import com.netadmin.toolkit.tools.WhoisScreen
import com.netadmin.toolkit.tools.WolScreen
import com.netadmin.toolkit.ui.NetTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        setContent { NetTheme { AppRoot() } }
    }
}

/** Tab id (used for "open this host in tool X") and title, in display order. */
private val PAGES = listOf(
    "info" to "Info",
    "wifi" to "Wi-Fi",
    "lan" to "LAN",
    "ping" to "Ping",
    "traceroute" to "Traceroute",
    "dns" to "DNS",
    "whois" to "Whois",
    "portscan" to "Port scan",
    "http" to "HTTP/TLS",
    "subnet" to "Subnet",
    "wol" to "Wake on LAN",
)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun AppRoot() {
    val scope = rememberCoroutineScope()
    val pager = rememberPagerState { PAGES.size }
    // Host handed from the LAN list to a tool: "ip#nonce" so tapping the same host again still refreshes.
    val prefill = remember { mutableStateMapOf<String, String>() }
    var nonce by remember { mutableIntStateOf(0) }

    fun openTool(route: String) {
        val id = route.substringBefore('?')
        val host = route.substringAfter("host=", "")
        if (host.isNotBlank()) prefill[id] = "$host#${nonce++}"
        val i = PAGES.indexOfFirst { it.first == id }
        if (i >= 0) scope.launch { pager.animateScrollToPage(i) }
    }
    fun host(id: String) = prefill[id].orEmpty()

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            Column(Modifier.background(MaterialTheme.colorScheme.surfaceContainerLow)) {
                TopAppBar(
                    title = { Text("NetAdmin Toolkit", fontWeight = FontWeight.SemiBold) },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
                    ),
                )
                ScrollableTabRow(
                    selectedTabIndex = pager.currentPage,
                    edgePadding = 8.dp,
                    containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
                    contentColor = MaterialTheme.colorScheme.primary,
                    divider = {},
                ) {
                    PAGES.forEachIndexed { i, (_, title) ->
                        Tab(
                            selected = pager.currentPage == i,
                            onClick = { scope.launch { pager.animateScrollToPage(i) } },
                            selectedContentColor = MaterialTheme.colorScheme.primary,
                            unselectedContentColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            text = { Text(title.uppercase(), fontWeight = FontWeight.SemiBold) },
                        )
                    }
                }
            }
        },
    ) { pad ->
        HorizontalPager(
            state = pager,
            // Keep every tab alive so running pings/scans continue when you swipe away.
            beyondViewportPageCount = PAGES.size,
            modifier = Modifier.fillMaxSize().padding(pad),
        ) { page ->
            when (PAGES[page].first) {
                "info" -> OverviewScreen()
                "wifi" -> WifiScreen()
                "lan" -> LanScreen(::openTool)
                "ping" -> PingScreen(host("ping"))
                "traceroute" -> TracerouteScreen(host("traceroute"))
                "dns" -> DnsScreen(host("dns"))
                "whois" -> WhoisScreen(host("whois"))
                "portscan" -> PortScanScreen(host("portscan"))
                "http" -> HttpScreen(host("http"))
                "subnet" -> SubnetScreen()
                "wol" -> WolScreen()
            }
        }
    }
}
