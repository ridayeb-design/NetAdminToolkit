package com.netadmin.toolkit

import android.app.Application
import org.xbill.DNS.config.AndroidResolverConfigProvider

class NetToolkitApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // dnsjava needs a Context on Android to discover the system resolvers.
        runCatching { AndroidResolverConfigProvider.setContext(this) }
    }
}
