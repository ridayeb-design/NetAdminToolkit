package com.netadmin.toolkit.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.Lan
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Router
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.netadmin.toolkit.net.LanHost
import com.netadmin.toolkit.net.LanScanner
import com.netadmin.toolkit.net.NetInfo
import com.netadmin.toolkit.net.clean
import com.netadmin.toolkit.net.ipToLong
import com.netadmin.toolkit.net.lanLink
import com.netadmin.toolkit.net.longToIp
import com.netadmin.toolkit.net.macIsRandomized
import com.netadmin.toolkit.net.prefixToMask
import com.netadmin.toolkit.tools.serviceName
import com.netadmin.toolkit.ui.Hint
import com.netadmin.toolkit.ui.InfoCard
import com.netadmin.toolkit.ui.KV
import com.netadmin.toolkit.ui.RunStopButton
import com.netadmin.toolkit.ui.copyToClipboard
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

@Composable
fun LanScreen(openTool: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val link = remember { ctx.lanLink() }
    val selfIp = link.ipv4?.clean()
    val prefix = link.ipv4Prefix ?: 24
    val gateway = link.gateway

    // Large subnets: sweep only the /24 (or /22 max) around us.
    val scanPrefix = prefix.coerceAtLeast(22)
    val mask = prefixToMask(scanPrefix)
    val net = selfIp?.let { ipToLong(it) and mask }
    val bcast = net?.let { it or (mask.inv() and 0xFFFFFFFFL) }
    val first = net?.let { if (scanPrefix >= 31) it else it + 1 }
    val last = bcast?.let { if (scanPrefix >= 31) it else it - 1 }
    val total = if (first != null && last != null) (last - first + 1).toInt() else 0

    val hosts = remember { mutableStateListOf<LanHost>() }
    var progress by remember { mutableIntStateOf(0) }
    var job by remember { mutableStateOf<Job?>(null) }
    var status by remember { mutableStateOf<String?>(null) }
    var selected by remember { mutableStateOf<LanHost?>(null) }

    LazyColumn(Modifier.fillMaxSize()) {
        item {
            InfoCard("Local network", Icons.Default.Lan) {
                KV("Connection", NetInfo.transports(link.caps))
                KV("Interface", link.lp?.interfaceName)
                KV("This device", selfIp?.let { "$it/$prefix" })
                KV("Gateway", gateway)
                KV("DNS", link.dns.joinToString(", "))
                if (net != null) {
                    KV("Scan range", "${longToIp(first!!)} – ${longToIp(last!!)} ($total hosts)")
                    if (prefix < scanPrefix) Text(
                        "Subnet is /$prefix; scanning the /$scanPrefix around this device.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
                Spacer(Modifier.height(8.dp))
                RunStopButton(
                    running = job?.isActive == true,
                    runLabel = "Scan network",
                    onRun = {
                        if (first == null || last == null) { status = "No IPv4 LAN connection"; return@RunStopButton }
                        hosts.clear(); progress = 0; status = "Scanning…"
                        val t0 = System.currentTimeMillis()
                        job = scope.launch {
                            try {
                                LanScanner.scan(
                                    first, last, selfIp, gateway,
                                    onProgress = { progress = it },
                                    onFound = { h ->
                                        val at = hosts.indexOfFirst { ipToLong(it.ip) > ipToLong(h.ip) }
                                        if (at < 0) hosts.add(h) else hosts.add(at, h)
                                        if (progress >= total) status = "Resolving names & ports…"
                                    },
                                    onUpdate = { u ->
                                        val i = hosts.indexOfFirst { it.ip == u.ip }
                                        if (i >= 0) hosts[i] = u
                                    },
                                )
                                status = "${hosts.size} hosts up · ${(System.currentTimeMillis() - t0) / 1000}s"
                            } finally {
                                if (status == "Scanning…" || status?.startsWith("Resolving") == true) status = "Stopped"
                            }
                        }
                    },
                    onStop = { job?.cancel() },
                )
                if (job?.isActive == true && total > 0) {
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(progress = { progress / total.toFloat() }, modifier = Modifier.fillMaxWidth())
                }
                status?.let { Text(it, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp)) }
            }
        }
        items(hosts, key = { it.ip }) { h -> HostCard(h) { selected = h } }
        item {
            Hint("Detection uses ICMP + TCP probes, reverse DNS and NetBIOS. Android 10+ blocks the ARP table, so MACs appear only for hosts that answer NetBIOS (Windows/Samba).")
            Spacer(Modifier.height(24.dp))
        }
    }

    selected?.let { h ->
        AlertDialog(
            onDismissRequest = { selected = null },
            title = { Text(h.ip) },
            text = {
                Column {
                    KV("Name", h.hostname ?: h.netbios)
                    KV("MAC", h.mac)
                    KV("Latency", h.latencyMs?.let { "$it ms (${h.method})" })
                    KV("Open ports", h.openPorts.joinToString(", ") { "$it/${serviceName(it)}" }.ifEmpty { "none of the probed" })
                }
            },
            confirmButton = {
                Column(horizontalAlignment = Alignment.End) {
                    TextButton(onClick = { selected = null; openTool("ping?host=${h.ip}") }) { Text("Ping") }
                    TextButton(onClick = { selected = null; openTool("traceroute?host=${h.ip}") }) { Text("Traceroute") }
                    TextButton(onClick = { selected = null; openTool("portscan?host=${h.ip}") }) { Text("Port scan") }
                    TextButton(onClick = { selected = null; openTool("http?host=${h.ip}") }) { Text("HTTP check") }
                    TextButton(onClick = { ctx.copyToClipboard(h.ip) }) { Text("Copy IP") }
                }
            },
        )
    }
}

@Composable
private fun HostCard(h: LanHost, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                when { h.isGateway -> Icons.Default.Router; h.isSelf -> Icons.Default.PhoneAndroid; else -> Icons.Default.Computer },
                null, tint = MaterialTheme.colorScheme.primary,
            )
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(h.ip, fontWeight = FontWeight.SemiBold)
                    if (h.isGateway) Tag("GATEWAY")
                    if (h.isSelf) Tag("THIS DEVICE")
                }
                val name = h.hostname ?: h.netbios
                if (name != null) Text(name, style = MaterialTheme.typography.bodySmall)
                val extra = listOfNotNull(
                    h.mac?.let { if (macIsRandomized(it)) "$it (random)" else it },
                    h.openPorts.takeIf { it.isNotEmpty() }?.joinToString(",", prefix = "ports ")
                ).joinToString("  ·  ")
                if (extra.isNotEmpty()) Text(
                    extra, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Text(
                h.latencyMs?.let { "$it ms" } ?: "",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        HorizontalDivider(Modifier.padding(start = 56.dp), thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant)
    }
}

@Composable
private fun Tag(t: String) {
    Spacer(Modifier.width(8.dp))
    Text(
        t,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.primary,
        fontWeight = FontWeight.Bold,
    )
}
