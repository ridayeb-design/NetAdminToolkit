# NetAdmin Toolkit (Android)

Network-admin toolbox for your phone. Kotlin + Jetpack Compose, Android 8.0+ (API 26), no root needed.

## Features

**IP info (by layer)**
- Active transport (Wi-Fi / cellular / Ethernet / VPN), interface, carrier
- L2: MAC (if Android allows), MTU, estimated up/down bandwidth
- L3 IPv4: address/prefix, netmask, network, broadcast, gateway, DHCP server
- L3 IPv6: every address labelled global / ULA / link-local / temporary, v6 gateway, NAT64 prefix
- Full routing table, DNS servers, search domains, Private DNS (DoT) status, HTTP proxy/PAC
- Capabilities: validated, captive portal, metered, VPN, roaming
- Public IPv4/IPv6, reverse DNS, ISP/ASN, geolocation (from ipinfo.io / ipify)
- All networks and raw interfaces (wlan0, rmnet, tun0…)
- Refreshes on its own when the network changes. "Copy report" puts everything on the clipboard

**Wi-Fi**
- SSID, BSSID, security (WPA2/WPA3/OWE/EAP…), Wi-Fi standard (4/5/6/6E/7)
- RSSI + quality, frequency, band, channel, link / TX / RX / max speeds
- DHCP lease: IP, mask, gateway, DHCP server, DNS, lease time
- Live 90-second RSSI graph for walking site surveys
- Nearby AP scan: channel, width, security, standard, plus channel usage per band

**LAN scanner**
- Sweeps your subnet (up to a /22) with ICMP + TCP SYN/RST probes
- Reverse DNS, NetBIOS names and MACs (Windows/Samba), quick port check
- Flags the gateway and this device. Tap a host to ping, traceroute, port scan or run an HTTP check on it

**Tools**
- Ping: count, interval, size, TTL, IPv6, continuous mode, plus loss/min/avg/max/jitter
- Traceroute: parallel TTL probes, per-hop RTT, reverse DNS
- DNS: A/AAAA/CNAME/MX/NS/TXT/SOA/PTR/SRV/CAA/DS/DNSKEY/ANY against the system DNS, 1.1.1.1, 8.8.8.8, 9.9.9.9 or any server you enter, over UDP or TCP. You can query all common types at once
- Whois: domains, IPs and ASNs. Follows IANA → registry → registrar referrals
- Port scanner: presets or custom ranges, banner grabbing
- HTTP/TLS check: DNS/TCP/TLS/HTTP timings, status, headers, TLS version and cipher, cert chain, days to expiry, SANs, hostname match
- Subnet calculator: CIDR, wildcard, ranges, class/type, reverse zone, binary, splitting into smaller subnets
- Wake-on-LAN, with saved devices

## Build

### Option A – GitHub (no PC needed)
1. Create a new GitHub repository and upload the contents of this folder (keep `.github/`).
2. GitHub Actions runs **Build APK** on its own. Open the run → *Artifacts* → download `NetAdminToolkit-apk`.
3. Unzip and install `app-release.apk` on your phone (allow "Install unknown apps").

### Option B – Android Studio
Open the folder in Android Studio (Ladybug or newer), let Gradle sync, then click Run. You can also run `./gradlew assembleRelease`.

The release build is signed with the debug key so it installs directly. Use your own keystore if you distribute it.

## Android limitations
- **SSID/BSSID and Wi-Fi scan results** need the Location permission *and* Location turned on. Android enforces this.
- **Own MAC address** is hidden on Android 11+. Wi-Fi MACs are usually randomized per network.
- **ARP table** is blocked on Android 10+. The LAN scanner shows MACs only for hosts that answer NetBIOS.
- **Wi-Fi scans** are throttled to 4 per 2 minutes. You can turn off "Wi-Fi scan throttling" in Developer options.
- Ping and traceroute use the system `ping` binary. The minimum interval is 0.2 s without root.

Only scan networks you administer or are authorised to test.
